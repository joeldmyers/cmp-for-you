<?php

$dbhost = "localhost";
$dbuser = "patdbuser";
$dbpass = "oV]iovwPHCui";
$dbname = "patient";

$db_conx = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
// Evaluate the connection
if (mysqli_connect_errno()) {
    echo mysqli_connect_error();
    exit();
}

?>