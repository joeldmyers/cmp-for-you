<?php

$dbhost = "localhost";
$dbuser = "cm4uadmin";
$dbpass = "%Tl8]lW.@#+N";
$dbname = "cmforyoudb";

?>