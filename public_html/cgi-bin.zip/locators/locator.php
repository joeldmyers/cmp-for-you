<?

ini_set('error_reporting', E_ALL);

include 'cm4udbconnect.php'; //include database connection details
$mysqli = new MySQLi($dbhost,$dbuser,$dbpass,$dbname);
if ($mysqli->connect_errno) { echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error; }

?>

<html>
<head>

<style>
#nav {
    line-height:30px;
    background-color:#eeeeee;
    width:500px;
    float:left;
    padding:5px;	      
}
</style>

<title>Locator Function</title>
<link rel="stylesheet" type="text/css" href="../formstyle.css">


</head>
<body>
<h3 align="center">Locator</h3>
<hr>


<form name="locate" id="locate" method="POST" action="<? $PHP_SELF ?>" >

<table class=listing style='position:relative; left:32;'>
<td><strong>Enter City, State or Zip Code</strong></td>
<td><input type="text" name="query_string"></td>
<td><td><input type="submit" name="locateform" value="Submit" /></td>
</form>
</table>


<form name="zoom" id="locate" method="POST" action="<? $PHP_SELF ?>" >


<?

//form1 post completed here

if (!empty($_POST['locateform'])) 

{
     
$query_string = $_POST['query_string'];

if (is_numeric($query_string))
{
$sql= "select city,state from citystate where postal like '$query_string%' group by city,state order by city asc ";
//echo "$sql";
$result = $mysqli->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');
}
else
{

if (strlen($query_string)==2)
{
$sql= "select city,state from citystate where state='$query_string'  group by city,state order by city asc ";
//echo "$sql";
$result = $mysqli->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');
}

else
{
$sql= "select city,state from citystate where city like '%$query_string%' group by city,state order by city asc";
//echo "$sql";
$result = $mysqli->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');
}
}


if ( mysqli_num_rows($result) ==0)
{
echo "No data available";
}
else
{
?>

<table class=listing style='position:relative; left:32;'>
<td><strong>Select Closest Location for <?echo $query_string; ?></strong></td>
<td>

<select name="zoom_select"  method="post">
												<?php
												// code to remember previous criteria selection 
												if ($_POST['zoom_select'])
												{
												 echo "<option value=".$_POST['zoom_select'].">".$_POST['zoom_select'] ."</option>";
												 echo "<option value=''>Select...</option>";
												}
												 else
												{
												 echo "<option value=''>Select...</option>";
												}
												//////  Build pick list from db												

											 while ($row = mysqli_fetch_array($result)) {
                                                                              
													$city  = $row[0];
													$state = $row[1];
                                                                                                        $citystate=$city.'#'.$state;
													echo "<option value=\"$citystate\">" . $city . ", " . $state . "</option>\n";
												} 
												?>
											</select>

<td><td><input type="submit" name="zoom" value="Submit" /></td>
</form>

</table>


<?

}

} // end else query string data available


//var_dump($_POST);

if (!empty($_POST['zoom_select'])) 

{ 

$data=explode("#",$_POST['zoom_select']);

//echo "<br>data is ";
//var_dump($data);


$city=$data[0];
$state=$data[1];
$loc=$city.', '.$state;


$sql= "select city,state,latitude,longitude from citystate where city = '$city' and state='$state'  limit 1";
//echo "$sql";
$result = $mysqli->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');

while ($row = mysqli_fetch_array($result)) {

$loc_lat=$row[2];
$loc_lng=$row[3];

//echo "LAT is $loc_lat";
//echo "LNG is $loc_lng";

}


search_area($loc_lat,$loc_lng,$loc,$mysqli);


}



function search_area($lat,$lng,$loc,$mysqli)
{


echo "<h3>Within 25 miles of $loc</h3>";


$sql= "SELECT facility_id,facility_name,facility_address,facility_city,facility_state,facility_phone, facility_type,
( 3959 * acos( cos( radians($lat) ) * cos( radians( facility_lat ) ) * cos( radians( facility_lng ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( facility_lat ) ) ) ) AS distance FROM facilities HAVING distance < 25 ORDER BY distance LIMIT 0 , 20";

//echo "$sql";


$result = $mysqli->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');


if ( mysqli_num_rows($result) == 0)
{

echo "No data available";

echo "<h3>Over 25 miles of $loc</h3>";


$sql= "SELECT facility_id,facility_name,facility_address,facility_city,facility_state,facility_phone, facility_type, 
( 3959 * acos( cos( radians($lat) ) * cos( radians( facility_lat ) ) * cos( radians( facility_lng ) - radians($lng) ) + sin( radians($lat) ) * sin( radians( facility_lat ) ) ) ) AS distance FROM facilities HAVING distance <50 ORDER BY distance LIMIT 0 , 20";

//echo "$sql";

$result = $mysqli->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');


}

if ( mysqli_num_rows($result) == 0)
{
echo "No data available";
}
else

{

echo "<div id=\"nav\">";
echo "<table class=listing style='position:relative; left:32;'>";

//echo "<th>id</th><th>Name</th><th>Address</th><th>City</th><th>State</th><th>Phone</th><th>Distance</th><th>Map</th><th>Directions</th>";

if(isset($_GET['showmap']))
{
    showmap();
}

   while ($row = mysqli_fetch_array($result)) {

$id=$row[0];        
$name=$row[1];     
$address=$row[2];
$city=$row[3];
$state=$row[4];
$phone=$row[5];
$type=$row[6];
$distance=round($row[7],2);


echo "<tr><td><hr>ID: $id - $type
<br>$name
<br>$address, $city, $state
<br>Ph:$phone
<br>Distance : $distance
<br><a href=\"map.php?id=$id&myloc=$loc\">Map</a>&nbsp|&nbsp<a href=\"directions.php?id=$id&myloc=$loc\">Directions</a><td>";

?>
<td>


<?
} // end while loop
echo "</table></div>";



} // end data available 

} // end function search_area



function showmap()
{
echo "hello";

//$id=$_GET['id'];

     

$sql= "select facility_name,facility_address,facility_city,facility_state from facilities where facility_id=1867 ";
//echo "$sql";
$result = $mysqli->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');

while ($row = mysqli_fetch_array($result)) {

$name=$row[0];
$address=$row[1];
$city=$row[2];
$state=$row[3];

}


$MAP_OBJECT = new GoogleMapAPI(); $MAP_OBJECT->_minify_js = isset($_REQUEST["min"])?FALSE:TRUE;
$MAP_OBJECT->setMapType('TERRAIN');
$MAP_OBJECT->addMarkerByAddress("$address, $city, $state","$name", "$name");

$MAP_OBJECT->getHeaderJS();
$MAP_OBJECT->getMapJS();

echo "<table>";
echo "<td>";

$MAP_OBJECT->printOnLoad();
$MAP_OBJECT->printMap();
//=$MAP_OBJECT->printSidebar();

echo "</td>";
echo "<td valign=top>";
echo "<table>";
echo "<td>$name</td>";
echo "<tr><td valign=top>$address, $city, $state</td>";

echo "</table>";
?>

<a href="http://chiosapps.com/fv_kanwar99/index.php?-table=facilities&-action=locator">Return to Locator</a>
<br>
<a href="http://chiosapps.com/fv_kanwar99/index.php?-table=facilities">Return To Database</a>
</td>
</table>

<?

} // end function show map



?>

</body>
</html>