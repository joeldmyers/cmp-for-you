<?php



//$servername = "localhost";
//$username = "patdbuser";
//$password = "oV]iovwPHCui";
//$dbname = "patient";


$pname = $_POST["pname"];
$paddress = $_POST["paddress"];
$hpnumber = $_POST["hpnumber"];
$dofb = $_POST["dofb"];
$languages =$_POST["languages"];
$symptoms =$_POST["symptoms"];
$problems = $_POST["problems"];
$treated = $_POST["treated"];
$insured = $_POST["insured"];
$medicare = $_POST["medicare"];
$medicaid = $_POST["medicaid"];
$va = $_POST["va"];
$cname = $_POST["cname"];
$pay = $_POST["pay"];
$login = $_POST["login"];
$password1 = $_POST["password1"];
$email = $_POST["email"];
$sex = $_POST["sex"];
$body_part=$_POST["body_part"];

// Create connection
include 'dbconnect.php'; //include database connection details
$conn = new MySQLi($dbhost,$dbuser,$dbpass,$dbname);

// Check connection
if ($conn->connect_errno) { echo "Failed to connect to MySQL: (" . $conn->connect_errno . ") " . $conn->connect_error; }

// $conn = new mysqli($servername, $username, $password, $dbname);
//if ($conn->connect_error) {
//    die("Connection failed: " . $conn->connect_error);
//}

$sql = "INSERT INTO patient (pname, paddress, hpnumber, dofb, languages, symptoms, problems, treated, insured, medicare, medicaid, va, cname, pay, login, password1, email, sex, body_part)
VALUES ('$pname', '$paddress', '$hpnumber', '$dofb', '$languages', '$symptoms', '$problems', '$treated', '$insured', '$medicare', '$medicaid', '$va', '$cname', '$pay', '$login', '$password1', '$email', '$sex', '$body_part')";



if ($conn->query($sql) === TRUE) {
    echo "<script language='javascript' type='text/javascript'>
alert('New Record Created Successfully!');
</script>";
} else {
    echo "<script language='javascript' type='text/javascript'>
alert('Error occurred while creating record! !');
</script> " . $sql . "<br>" . $conn->error;
}

$conn->close();
?> 