<html>

<head>
<link rel="stylesheet" type="text/css" href="formstyle.css">
</head>

<body>



<?
// Create connection
include 'dbconnect.php'; //include database connection details
$conn = new MySQLi($dbhost,$dbuser,$dbpass,$dbname);

// Check connection
if ($conn->connect_errno) { echo "Failed to connect to MySQL: (" . $conn->connect_errno . ") " . $conn->connect_error; }

$patient_email_hash = $_GET["hash"];

$sql= "select login from patients where patient_email_hash='$patient_email_hash' ";

//echo "$sql";

$result = $conn->query($sql) or die('<p>Query to get hash data from patients table failed:' . mysql_error() . '</p>');

if (mysqli_num_rows($result)==0)
{
     $account_enabled=0;
     echo "<font color='red'>ID NOT Validated</font>";
     echo "<br>Return to site";
     
}  


while ($row = mysqli_fetch_row($result)) {

$user_name   = $row[0];

echo "<p>Hello $user_name ! - Your account is now active. Please complete the information requested below";

$datetime_activated=date("Y-m-d H:i:s");

$sql= "update patients set patient_status='ACTIVE',datetime_activated='$datetime_activated' where patient_email_hash='$patient_email_hash' ";

$account_enabled=1;

//echo "$sql";
$result = $conn->query($sql) or die('<p>Query to save data to patients table failed:' . mysql_error() . '</p>');

} // end user validated

?>



<? if ($account_enabled) { ?>

<h3 align="center">Patient Registration</h3>

<form name = "pdi" action="pdisavereg.php" method="POST" class="form-style-1" >

<table>
<tr>
<td>Patient Last Name</td>
<td><input type="text" name="last" id="last" size=35 required></td>
<tr>
<td>Patient First Name</td>
<td><input type="text" name="first" size=35></td>
<tr>
<td>Street Address </td>
<td><input type="text" name="address" size=50></td>
<tr>
<td>City</td>
<td><input type="text" name="city" size=40></td>
<tr>
<td>State</td>
<td>
<select name="state">
        <option value="">Select</option>
	<option value="AL">Alabama</option>
	<option value="AK">Alaska</option>
	<option value="AZ">Arizona</option>
	<option value="AR">Arkansas</option>
	<option value="CA">California</option>
	<option value="CO">Colorado</option>
	<option value="CT">Connecticut</option>
	<option value="DE">Delaware</option>
	<option value="DC">District Of Columbia</option>
	<option value="FL">Florida</option>
	<option value="GA">Georgia</option>
	<option value="HI">Hawaii</option>
	<option value="ID">Idaho</option>
	<option value="IL">Illinois</option>
	<option value="IN">Indiana</option>
	<option value="IA">Iowa</option>
	<option value="KS">Kansas</option>
	<option value="KY">Kentucky</option>
	<option value="LA">Louisiana</option>
	<option value="ME">Maine</option>
	<option value="MD">Maryland</option>
	<option value="MA">Massachusetts</option>
	<option value="MI">Michigan</option>
	<option value="MN">Minnesota</option>
	<option value="MS">Mississippi</option>
	<option value="MO">Missouri</option>
	<option value="MT">Montana</option>
	<option value="NE">Nebraska</option>
	<option value="NV">Nevada</option>
	<option value="NH">New Hampshire</option>
	<option value="NJ">New Jersey</option>
	<option value="NM">New Mexico</option>
	<option value="NY">New York</option>
	<option value="NC">North Carolina</option>
	<option value="ND">North Dakota</option>
	<option value="OH">Ohio</option>
	<option value="OK">Oklahoma</option>
	<option value="OR">Oregon</option>
	<option value="PA">Pennsylvania</option>
	<option value="RI">Rhode Island</option>
	<option value="SC">South Carolina</option>
	<option value="SD">South Dakota</option>
	<option value="TN">Tennessee</option>
	<option value="TX">Texas</option>
	<option value="UT">Utah</option>
	<option value="VT">Vermont</option>
	<option value="VA">Virginia</option>
	<option value="WA">Washington</option>
	<option value="WV">West Virginia</option>
	<option value="WI">Wisconsin</option>
	<option value="WY">Wyoming</option>
        <option value="AS">American Samoa</option>
        <option value="GU">Guam</option>
        <option value="MP">Northern Mariana Islands</option>
        <option value="PR">Puerto Rico</option>
        <option value="UM">United States Minor Outlying Islands</option>
        <option value="VI">Virgin Islands</option>
</select>			
<tr>
<td>Zip</td>
<td><input type="text" name="zip"></td>

<tr>

<td>Home Phone Number</td>
<td><input type="text" name="hpnumber" size=20></td>
<tr>
<td>Date Of Birth</td>
<td><input type="date" name="dofb" required></td>
<tr>
<td>Languages</td>
<td><input type="text" name="languages"></td>
<tr>
<td>Sex</td>
<td>
<input type="radio" name="sex" value="Male">Male
<input type="radio" name="sex" value="Female">Female
</td>
<tr>
<td>Treatment Location</td>
<td>
<input type="radio" name="treated" value="Home">At Home
<input type="radio" name="treated" value="NHome">Nursing Home
<input type="radio" name="treated" value="Doctors">Doctors Office
<input type="radio" name="treated" value="Clinic">A Clinic
<input type="radio" name="treated" value="Hospital">Hospital
</td>
<tr>
<td>Insured</td>
<td>
<input type="radio" name="insured" value="YES">YES
<input type="radio" name="insured" value="NO">NO
<input type="radio" name="insured" value="UKNOWN">DON'T KNOW
</td>
<tr>
<td>Insurance Company Name</td>
<td>

<select name="insurance">
																											
<option value="select insurance">Select Insurance</option>
<?
$sql="select insurance_name from insurance_companies order by insurance_name asc";
$result = $conn->query($sql) or die('<p>Query to get insurance data failed: ' . mysql_error() . '</p>');
while($row = mysqli_fetch_row($result)) {
$insurance_name=$row[0];

echo "<option value=\"$insurance_name\">$insurance_name</option>";

}

?>
														
</select>
														
</td>
<tr>
<td>Medicare</td>
<td>
<input type="radio" name="medicare" value="YES">YES
<input type="radio" name="medicare" value="NO">NO
</td>
<tr>
<td>Medicaid</td>
<td>
<input type="radio" name="medicaid" value="YES">YES
<input type="radio" name="medicaid" value="NO">NO
</td>
<tr>
<td>VA Insurance</td>
<td>
<input type="radio" name="va" value="YES">YES
<input type="radio" name="va" value="NO">NO
</td>
<tr>
<td>Desired Hourly Payment</td>
<td><input type="text" name="pay"></td>
</table>

<input type="hidden" name="patient_email_hash" value="<?echo $patient_email_hash;?>">


<hr>
<table>
<td><input type="submit" name="submit" value="Save and Continue"></td>
<td>
<td><input type="reset" name="reset" value="Reset"></td>
</table>

<?
}
?>

</body>
</html>