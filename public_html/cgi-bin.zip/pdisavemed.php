<?

// Create connection
include 'dbconnect.php'; //include database connection details
$conn = new MySQLi($dbhost,$dbuser,$dbpass,$dbname);

// Check connection
if ($conn->connect_errno) { echo "Failed to connect to MySQL: (" . $conn->connect_errno . ") " . $conn->connect_error; }



$patient_hash=$_POST["patient_hash"];

$problems = $_POST["problems"];
$body_part = $_POST["cat"];
$symptom1 = $_POST["symptom1"];
$symptom2 = $_POST["symptom2"];
$symptom3 = $_POST["symptom3"];
$allergies = $_POST["allergies"];
$meds1 = $_POST["meds1"];
$meds2 = $_POST["meds2"];
$meds3 = $_POST["meds3"];
$painstrength = $_POST["painstrength"];
$pain_inbody = $_POST["pain_inbody"];
$family_history = $_POST["family_history"];

$sql = "update patients 
set problems = '$problems',
body_part = '$body_part',
symptom1 = '$symptom1',
symptom2 = '$symptom2',
symptom3 = '$symptom3',
allergies = '$allergies',
meds1 = '$meds1',
meds2 = '$meds2',
meds3 = '$meds3',
painstrength = '$painstrength',
pain_inbody = '$pain_inbody',
family_history = '$family_history' 

where 

patient_hash= '$patient_hash' ";

if ($conn->query($sql) != TRUE) {
echo "<script language='javascript' type='text/javascript'>
alert('Error occurred while creating record! !');
</script> " . $sql . "<br>" . $conn->error;
}
else
{
echo "Medical Information Saved. Return to Site";
}


