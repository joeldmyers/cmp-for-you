<?
include 'dbconnect.php'; //include database connection details
$mysqli = new MySQLi($dbhost,$dbuser,$dbpass,$dbname);
if ($mysqli->connect_errno) { echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error; }

?>

<html>
<head>
<link rel="stylesheet" type="text/css" href="formstyle.css">
</head>

<body>


<h3>User Registration</h3>
<form name="user_registration" id="user_reg" method="post" action="<?= $PHP_SELF ?>" class="form-style-1">
<table>

<tr><td>Please enter your email address</td>
<td><input type="text" name="user_email" required></td>

<tr><td>Please enter a username</td>
<td><input type="text" name="user_name" required></td>

<tr><td>Please enter a password</td>
<td><input type="text" name="user_password" required></td>
</table>

<input type="submit" name="Submit">
</form>

<?

$user_email=$_POST['user_email'];
$user_name=$_POST['user_name'];
$user_password=$_POST['user_password'];


if ($user_email !="" && $user_name!="" && $user_password!="")
{

$sql= "select patient_id from patients where email='$user_email' or login='$user_name' ";

$result = $mysqli->query($sql) or die('<p>Error getting data from patients table:' . mysql_error() . '</p>');
$row_count=mysqli_num_rows($result);

if ($row_count >0)
{
echo "This email address and/or user name are already on file. Please enter a different email address and/or user name";
}
else
{
$patient_email_hash=md5( generateRandomString() );
//$regdate=date('Y-m-d');

$sql="insert into patients (email,patient_email_hash,login,password,patient_status) 
values ('$user_email','$patient_email_hash','$user_name','$user_password','DISABLED') ";

$mysqli->query($sql) or die('<p>Error saving data in patients table:' . mysql_error() . '</p>');

echo "The user information below that you submitted has been saved.";

echo "<hr>";
echo "username: $user_name";
echo "<br>password: $user_password";
echo "<br>email: $user_email";
echo "<hr>";

echo "Please take a moment to copy these credentials in a safe place.<br>";
echo "Then please check you incoming email messages. You will receive a confirmation email with instructions in order to activate your account";


//Email out the information if all is ok

$from="accounts@cmpforyou.com";
$subject = "Account Activation Notice";

// make sure subject text is utf8 so it is readable
$subject="=?UTF-8?B?".base64_encode($subject)."?=";

$message = "

Hi !

We have received a registration request from this email address.
Please click at the url listed below in order to activate your account.

http://www.cmpforyou.com/pdinput.php?hash=$patient_email_hash

If you have not requested to register with us, please accept our apologies and simply ignore and delete this message.

Thank you.


";

$mailto="$user_email";
$headers = "From: ".$from."\r\n";
$headers .= "Reply-To: ".$from."\r\n";
$headers .= "Return-Path: ".$from."\r\n";
//$headers .= "BCC: xxxxx@xxxx,xxxx@xxxx\r\n";

          if(!mail($mailto, $subject, $message,$headers)){
             die ("<div class='error'>Sending Email Failed. Please Report this error</div>");
          }
         else
          {

//                error('New Password Email Sent!.');

         }

}

} // end check if fields have been completed

?>

</body>
</html>



<?
function generateRandomString($length = 40) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

?>