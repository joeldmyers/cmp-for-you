<?php 
include 'dbconnect.php'; 
$defimg_woman="uploads/default-woman.jpg" ; 
$defimg_man="uploads/default-man.jpg" ; 
$ajax_load='<div class="ajax-loader"><img src="img/ajax-loader.gif"></div>' ; 
?>
<!doctype html>
<html lang="en">

<head>
    <title>Symptoms Services</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/bootstrap.css" />
    <link rel="stylesheet" href="css/re.css" />
    <style type="text/css">
        body,
        html,
        .row-offcanvas {
            height: 100%;
        }
        
        body {
            padding-top: 50px;
        }
        
        #sidebar {
            width: inherit;
            min-width: 280px;
            max-width: 280px;
            background-color: #f5f5f5;
            float: left;
            height: 100%;
            position: relative;
            overflow-y: auto;
            overflow-x: hidden;
        }
        
        #main {
            height: 100%;
            overflow: auto;
        }
        
        .row-offcanvas {
            margin-top: 45px !important;
        }
        
        .mf-parts {
            margin: 0;
        }
        
        .mf-part-1,
        .mf-part-2,
        .mf-part-3 {
            height: 400px;
            overflow: auto;
            border: 1px solid #DDD;
            -moz-border: 1px solid #DDD;
            -webkit-border: 1px solid #DDD;
            padding: 5px;
            border-right: 0;
        }
        
        .mf-part-3 {
            border-right: 1px solid #DDD;
            -moz-border-right: 1px solid #DDD;
            -webkit-border-right: 1px solid #DDD;
        }
        
        .tab-pane {
            border-left: 1px solid #DDD;
            -moz-border-left: 1px solid #DDD;
            -webkit-border-left: 1px solid #DDD;
            border-right: 1px solid #DDD;
            -moz-border-right: 1px solid #DDD;
            -webkit-border-right: 1px solid #DDD;
            border-bottom: 1px solid #DDD;
            -moz-border-bottom: 1px solid #DDD;
            -webkit-border-bottom: 1px solid #DDD;
            border-radius: 0px 0px 5px 5px;
            -moz-border-radius: 0px 0px 5px 5px;
            -webkit-border-radius: 0px 0px 5px 5px;
            padding: 10px;
            margin-bottom: 20px;
        }
        
        .nav-tabs {
            margin-bottom: 0;
        }
        
        .mf-part-1 .heading,
        .mf-part-2 .heading,
        .mf-part-3 .heading {
            border: 1px solid #DDD;
            -moz-border: 1px solid #DDD;
            -webkit-border: 1px solid #DDD;
            padding: 5px;
            width: 100%;
            margin: 0 0 10px 0;
            background: #DDD;
        }
        
        .mf-part-action {
            border: 1px solid #DDD;
            -moz-border: 1px solid #DDD;
            -webkit-border: 1px solid #DDD;
            padding: 5px;
            margin-top: 10px;
            text-align: right;
        }
        
        .form-horizontal label.radio-inline,
        label.checkbox-inline {
            cursor: pointer;
            font-weight: 400;
            display: block;
            clear: both;
            margin: 0;
            padding: 5px 0 0 0;
        }
        
        .custom-radio {
            width: 21px;
            height: 16px;
            display: inline-block;
            position: relative;
            z-index: 1;
            top: 3px;
            background: url("img/radio.png") no-repeat;
        }
        
        .custom-radio:hover {
            background: url("img/radio-hover.png") no-repeat;
        }
        
        .custom-radio.selected {
            background: url("img/radio-selected.png") no-repeat;
        }
        
        .custom-radio input[type="radio"] {
            margin: 1px;
            position: absolute;
            z-index: 2;
            cursor: pointer;
            outline: none;
            opacity: 0;
            /* CSS hacks for older browsers */
            
            _noFocusLine: expression(this.hideFocus=true);
            -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";
            filter: alpha(opacity=0);
            -khtml-opacity: 0;
            -moz-opacity: 0;
        }
        
        .ajax-loader {
            margin-top: 48%;
            text-align: center;
        }
        /*
         * off Canvas sidebar
         * --------------------------------------------------
         */
        
        @media screen and (max-width: 768px) {
            .row-offcanvas {
                position: relative;
                -webkit-transition: all 0.25s ease-out;
                -moz-transition: all 0.25s ease-out;
                transition: all 0.25s ease-out;
                width: calc(100% + 220px);
            }
            .row-offcanvas-left {
                left: -220px;
            }
            .row-offcanvas-left.active {
                left: 0;
            }
            .sidebar-offcanvas {
                position: absolute;
                top: 0;
            }
        }
    </style>
</head>

<body>
    <div class="navbar navbar-inverse navbar-fixed-top">
        <div class="navbar-header">
            <a class="navbar-brand" href="#"><img src="logo.png"> <b style="color:#FFF">  </b></a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
            </ul>
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="index.html"> <span class="glyphicon  glyphicon-home"></span> Home </a>
                </li>
                <li>
                    <a href="aboutus.html"> <span class="glyphicon glyphicon-th-large"></span> About </a>
                </li>
                <li><a href="signup.html"><span class="glyphicon glyphicon-user" ></span> Sign Up</a></li>
                <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Log in  </a></li>
                <li>
                    <form class="navbar-form navbar-left" role="search">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Search">
                        </div>
                        <button type="submit" class="btn btn-default"><span class="glyphicon glyphicon-search"></span> </button>
                    </form>
        </div>
        </ul>
    </div>
    <!--/.nav-collapse -->
    </div>
    <!--/.navbar -->
    <div class="row-offcanvas row-offcanvas-left">
        <div id="sidebar" class="sidebar-offcanvas">
            <div class="col-md-12">
                <ul class="nav nav-pills nav-stacked">
                    <li>
                        <a href="#"> </a>
                    </li>
                    <li>
                        <a href="#"><img src="img/Symptoms_2.png"> <b>Symptoms </b> </a>
                    </li>
                    <li>
                        <a href="#"><img src="img/Home_health_services.png"><b> Home Health Services</b> <i class="fa fa-fw fa-caret-down"></i> </a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo" class="" aria-expanded="true"><img src="img/Nursing_home.png"><b>  Nursing Homes </b></a>
                        <ul id="demo" class="collapse out" aria-expanded="true" style="list-style: none; line-height: 2;">
                            <li>
                                <a href="#">Home health service providers</a>
                            </li>
                            <li>
                                <a href="#">Nursing Homes</a>
                            </li>
                            <li>
                                <a href="#">Outpatient Clinic</a>
                            </li>
                            <li>
                                <a href="#">Hospitals</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="#"><img src="img/docter.png"><b>  Doctors </b></a>
                    </li>
                    <li>
                        <a href="#"><img src="img/Hospitals.png"><b> Hospitals </b></a>
                    </li>
                    <li>
                        <a href="#"><img src="img/Outpatient_clinic_1.png"> <b> Outpatient Clinic </b></a>
                    </li>
                </ul>
            </div>
        </div>
        <div id="main">
            <div><img src="img/symptoms.png" class="newre"> </div>
            <div class="col-md-12">
                <p class="visible-xs">
                    <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas"><i class="glyphicon glyphicon-chevron-left"></i></button>
                </p>
                <div align="center" style="font-size:30px;color:#F00"><b> Symptoms </b>
                    <br>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#male">Male</a></li>
                            <li><a data-toggle="tab" href="#female">Female</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="male" class="tab-pane fade in active">
                                <form class='form-horizontal'>
                                    <div class="row mf-parts">
                                        <div class="col-md-4 mf-part-1">
                                            <h4 class="heading">Select a Body Part</h4>
                                            <?php 
                        						$sql_male = "select * from body_areas";
                        						$result = mysqli_query($db_conx,$sql_male);
                                                $index = 0;
                        						while($db_field = mysqli_fetch_assoc($result))
                        						{ 
                        							$img = "uploads/".$db_field['man_body_img'];
                        							if(file_exists($img) && !empty($db_field['man_body_img']))
                        							{
                        								$img = "uploads/".$db_field['man_body_img'];
                        							}else{
                        								$img = $defimg_man;
                        							}
                                                        echo "<label class='radio-inline' for='area_man_".$db_field['area_id']."'>";
                        								echo "<input type='radio' id='area_man_".$db_field['area_id']."' name='area_man_id' class='male' value='".$db_field['area_id']."' data-href='".$img."'>";
                        								echo $db_field['area_descr']."</label>";
                                                        $index++;
                        						}
                        					?>
                                        </div>
                                        <div class="col-md-4 mf-part-2">
                                            <img src="<?php echo $defimg_man; ?>" class="img-responsive male-img">
                                        </div>
                                        <div class="col-md-4 mf-part-3 malesym"></div>
                                        <div class="col-md-12 mf-part-action">
                                            <button name="clear" class="btn btn-sm btn-danger male-clear" type="button">Clear Male</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div id="female" class="tab-pane fade">
                                <form class='form-horizontal'>
                                    <div class="row mf-parts">
                                        <div class="col-md-4 mf-part-1">
                                            <h4 class="heading">Select a Body Part</h4>
                                            <?php 
            						
                        						$sql_female = "select * from body_areas";
                        						$result_female = mysqli_query($db_conx,$sql_female);
                        						while($db_field_female = mysqli_fetch_assoc($result_female))
                        						{ 
                        							$img = "uploads/".$db_field_female['female_body_img'];
                        							if(file_exists($img) && !empty($db_field_female['female_body_img']))
                        							{
                        								$img = "uploads/".$db_field_female['female_body_img'];
                        							}else{
                        								$img = $defimg_woman;
                        							}
                                                        echo "<label class='radio-inline' for='area_women_".$db_field_female['area_id']."'>";
                        								echo "<input type='radio' id='area_women_".$db_field_female['area_id']."' name='area_woman_id' class='female' value='".$db_field_female['area_id']."' data-href='".$img."'>";
                        								echo $db_field_female['area_descr']."</label>";
                        							
                        						}
                        					?>
                                        </div>
                                        <div class="col-md-4 mf-part-1 text">
                                            <img src="<?php echo $defimg_woman; ?>" class="img-responsive female-img">
                                        </div>
                                        <div class="col-md-4 mf-part-1 femalesym"></div>
                                        <div class="col-md-12 mf-part-action">
                                            <button name="clear" class="btn btn-sm btn-danger female-clear" type="button">Clear Female</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--/row-offcanvas -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
        <script>
            var ajax_load = '<?php echo $ajax_load; ?>';
            var defimg_woman = '<?php echo $defimg_woman; ?>';
            var defimg_man = '<?php echo $defimg_man; ?>';
        </script>
        <script>
            //FOR MALE
            $(document).on('click', '.male', function() {

                var single_id = $("input:radio[name ='area_man_id']:checked").val();
                var img = $(this).attr('data-href');
                $('.male-img').attr('src', img);

                $('.malesym').html(ajax_load);
                jQuery.ajax({
                    type: "POST",
                    url: "get_ajax.php",
                    data: {
                        single_id: single_id,
                        gender: "Male"
                    },
                    success: function(html) {
                        jQuery(".malesym").html(html);
                        customRadio('male_sym_id');
                    }
                });

            });

            //FOR FEMALE
            $(document).on('click', '.female', function() {

                var single_id = $("input:radio[name ='area_woman_id']:checked").val();
                var img = $(this).attr('data-href');
                $('.female-img').attr('src', img);

                $('.femalesym').html(ajax_load);
                jQuery.ajax({
                    type: "POST",
                    url: "get_ajax.php",
                    data: {
                        single_id: single_id,
                        gender: "Female"
                    },
                    success: function(html) {
                        jQuery(".femalesym").html(html);
                        customRadio('fem_sym_id');
                    }
                });

            });

            //CUSTOM RADIO
            function clearRadio(radioName) {
                var radioButton = $('input[name="' + radioName + '"]');
                $(radioButton).each(function() {
                    $(this).closest('.custom-radio').removeClass('selected');
                });
            }

            function customRadio(radioName) {
                var radioButton = $('input[name="' + radioName + '"]');
                $(radioButton).each(function() {
                    $(this).wrap("<span class='custom-radio'></span>");
                    if ($(this).is(':checked')) {
                        $(this).parent().addClass("selected");
                    }
                });
                $(radioButton).click(function() {
                    if ($(this).is(':checked')) {
                        $(this).parent().addClass("selected");
                    }
                    $(radioButton).not(this).each(function() {
                        $(this).parent().removeClass("selected");
                    });
                });
            }
            $(document).ready(function() {
                customRadio("area_man_id");
                customRadio("area_woman_id");
            })


            //MALE CLEAR
            $(document).on('click', '.male-clear', function() {
                maleclear(defimg_man);
            });

            function maleclear() {
                $('.male-img').attr('src', defimg_man);
                clearRadio("area_man_id");
                $('.malesym').html('');
            }

            //FEMALE CLEAR
            $(document).on('click', '.female-clear', function() {
                femclear();
            });

            function femclear() {
                $('.female-img').attr('src', defimg_woman);
                clearRadio("area_woman_id");
                $('.femalesym').html('');
            }
        </script>
        <script>
            $(document).ready(function() {
                $('[data-toggle=offcanvas]').click(function() {
                    $('.row-offcanvas').toggleClass('active');
                });
            });
        </script>
</body>

</html>