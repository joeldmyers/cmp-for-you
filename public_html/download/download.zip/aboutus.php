<?php 
require_once("includes/top.php"); 
require_once("includes/header.php"); 
?>
<div class="container"><div class="row"><img src="<?=$remotelocation;?>includes/images/02.jpg" class="img-responsive margin-top-40"></div></div>
     
   <div class="container">
    <div class="innercontent row">
    <div class="col-md-12" style="padding:10px 60px;">
<h3 class="text-center"> About Custom Medical Services </h3>
<div class="row margin-bottom-40">
	<div class="col-md-1"></div>
    <div class="col-md-10 text-center">
    <h5 class="small-heading"> Mission:</h5>
It is to deliver easy access to thousands of Healthcare professionals through a cost effective technology driven medical and 
healthcare platform that will achieve high quality care at home or at any facility.
</div><div class="col-md-1"></div>
</div>


<div class="row margin-bottom-20">
	<div class="col-md-1"></div>
    <div class="col-md-10 text-center">
    <h5 class="small-heading"> We want to make a difference:</h5>
    Log term chronic conditions such as heart  ailment, stroke, cancer, diabetes, pre diabetes and respiratory maladies are  among the most common health problems in the USA and also worldwide but the fact is that most of them are now reversible.100 is the new 60 and our goal is make you all  lead a happy and healthy life by providing affordable care to all.<br><br>

Online healthcare service and drug information is now the most people searched topic on the Internet.
 A growing number of specialists are using the Internet to give immediate online health tips and advice in rural areas through broadband and videoconferencing systems. A physician can play a vital role in improving medical health care systems by using online digital technology.
</div><div class="col-md-1"></div>
</div>




<!--<img src="images/6.png"><br> <br>-->
 <div class="text-center">
The body of healthcare related knowledge is too large and extremely complex for any single person to master.</div>
<!--<div align="center"><img src="images/5.png"></div>-->
<div class="text-center">However, the learning curve for any individual to obtain general knowledge about prevention and<br>
 how to reverse their own symptoms is attainable.
</div><br>

<!--<img src="images/7.png"><br> --><br>
<div class="text-center margin-bottom-40">At <strong>Custom Medical Services For You</strong>, we are excited to make YOU the center of healthcare policy and industry trends. <br>
Patient engagement is an important factor in order to improve quality and service.</div>     


<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<hr class="margin-bottom-30">
<h5 class="small-heading">We are at the start of building an exciting company that will:</h5>
<ul style="margin-left:-20px;">
<li>Make a difference by engaging exceptional physicians and the latest technology from around the world . We are here introducing the best medical experts to consumers and patients. Later the same experts may treat the patients. <br>We are not involved with that part.</li>
<li>Medical Experts on our web site and specialists utilizing  www.CMPForYou.com are not employees or independent contractor service providers of our company. Any opinions, advice, or information expressed by any such professionals are those of the professional and the professional alone and they do not reflect the opinions of Our Company</li>
</ul>

It’s a known fact that patients feel more comfortable and convenient when treated at home by home health service providers, 
then nursing homes, outpatient clinics and finally if necessary in a hospital. 
In addition most patients would rather have an online consultation by messaging or video to obtain information, guidance  and second opinion rather than travel to a doctor’s office. 
Our platform incorporates HIPAA  - compliant telecommunication System.
<br><br> 
Another important element of our approach is to provide a platform for doctors, nurses and other health providers to serve the patients in their spare time after they finish their full time duties whether it is during the week, or weekends or during the holidays. <br><br> 


Once we introduce the patient to the health care provider, we leave the treatment process to them including collection from Medicare and Insurance Companies.
<br>
You can locate more doctors   on our site in a few minutes   than 100 hospitals combined. Our goal is to offer the most advanced and research based technologies, while being mindful of the financial constraints of your long or short-term needs.  Our team of experts is constantly available to find solutions to your problems.
<br><br> You can get basic online consultation for a small fee at less than the cost of a meal. Advanced video online consultations where you receive face-to-face consultation are also available; it’s like magic. You save an average of three hours this way compared to a visit to the doctor’s office.
<br><strong>On April 28, 2014, the FSMB (Federation of State Medical Boards)</strong> approved telemedicine <i>consultations between physician and patient being equivalent to in-person consultations as long as the interaction was done via videoconference. </i>

<hr class="margin-top-30">
<div class="text-center">
<strong>We are  Not a Medical Provider and Do Not Provide Medical Treatment on our website.</strong><br>
You should seek   medical diagnosis, or treatment, or other professional healthcare help from your own medical doctor or the applicable health care provider.  In case of a medical emergency, call 911 ASAP. Any online consultation with medical experts by online messaging and/or live video consultation is meant for providing information and second opinion on day to day health problems or chronic diseases.
</div>

<hr class="margin-top-30">
<div class="text-center margin-top-40">
<h5 class="small-heading">Joining this site is FREE.</h5>
Some doctors are not all available all the time but with a quick search you will find one nearby or further away.<br>
This will save you a trip to the hospital or a sleepless night worrying about something, which may not even exist.<br>
 So what are you waiting for?<br>
Join us today by registering yourself and other loved ones who are too old or too young to do it themselves.
Whether you are rich, poor or in between, you do not deserve to be miserable. It is a known saying that, “health is wealth.” Paying the physician and the nurse beyond their expectations, for all the wealth in the world cannot make you happy unless you are healthy and free of pain. 
</div>
<hr class="margin-top-30">
<h5 class="small-heading margin-bottom-10 margin-top-40">The following is for doctors and nurses and other medical service providers </h5>
 <div>There is a massive revolution occurring in the medical industry. If you want to grab the future by the horns and even command it to serve your needs, come and join us. Most healthcare practitioners are engaged in the standard 8-hour per day job. What   do you do in the extra time in between? Why not spare your extra time to offer humanitarian services to mankind and in the process get extra pay.  You will get more new patients while keeping your existing ones. Prepare for renewed prosperity while the industry twists and turns, and set yourself up to profit from this.
At the same time make somebody happy and healthy.
<ul class="margin-top-30">
<li>Physicians and Nurses and other Medical Service Providers all over are facing the realty of doing more for less. We want you to focus on what is happening to the industry today. Not hype. Not theory. Not scare tactics. Just business realty</li>
<li>You are the one who took the Hippocratic oath. “You do not treat a fever chart, a cancerous growth, but a sick human being, whose illness may affect the person's family and economic stability. Your responsibility includes these related problems, if you aim to care adequately for the sick.</li>
<li>No Paperwork ,      No RedTape,         Get Paid Sooner</li>
<li>Make Somebody Happy</li>

</ul>
<br>
<img src="<?=$remotelocation;?>includes/images/8.png" class="img-responsive margin-top-30 margin-bottom-30"> Our aging population is increasing exponentially. They can be cured only if you start treating these patients at their homes or at a nursing home or at a medical group office or at outpatient center or dialysis center or even at a hospital, which provides home centered services making use of the extra hours you have. Our platform helps you do that. Just register at our site and let the magic begin.<br>
<ul class="margin-top-30"><li>A country, which sends its physicians and nurses to Africa to fight the Ebola virus, surely can expect us to help cure our own aging population and rid their afflictions and pain so that they can spend the balance of their years happily enjoying their grandchildren and other family members.</li></ul>
 </div>
 
 <hr class="margin-top-30">
 <div class="small-heading text-center">As a doctor or nurse, “you will be respected while you live and remembered with affection afterwards.”<br>
So come join us. It takes only 10 minutes of your time to join us, which is also free. Let the renaissance into a more productive life for doctors and nurses begin. It  will be also affordable for  patients. It is a win-win solution for everybody.
</div>
</div>
<div class="col-md-1"></div>
</div>

</div>
 </div>
</div> 
<?php require_once("includes/footer.php"); ?>    