<?php
require_once("includes/top.php");
require_once("includes/doc_authentication.php");
global $db;
$state_list = $db->Execute("select", "select sta_id,sta_name FROM " . STATES . " where sta_couid = '1'");
//$state_list = $db->Execute("select", "select sta_id,sta_name FROM " . STATES . " where sta_couid = '1'");
// echo "<pre/>"; print_r($state_list); exit;
?>
<?php require_once("includes/docheader.php"); ?>    
    <script src="<?=$remotelocation;?>includes/js/jquery.js"></script>
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.plugins.min.js"></script>			
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.revolution.min.js"></script>
    <script src="<?=$remotelocation;?>includes/js/medical.min.js"></script>	
    <script src="<?=$remotelocation;?>includes/js/jquery.validate.min.js"></script>
    <!--<script src="<?=$remotelocation;?>includes/js/bootstrap.min.js"></script>-->
    <script src="<?=$remotelocation;?>includes/js/dhtmlgoodies_calendar.js?random=20060118"></script>
    
<div class="col-md-12 col-xs-12">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="<?=$remotelocation;?>includes/css/dhtmlgoodies_calendar.css?random=20051112">
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<div class="container">
    <style type="text/css">
        #accountForm {
            margin-top: 15px;
        }
        .cal_image {  background: url(includes/images/calendra.gif) no-repeat;  width: 20px; height: 20px;margin-top: 10px !important;}
        .monthYearPicker{    color:#FFFFFF !important;}
        #calendarDiv table{ clear: both;}
       .cal_image{ position: absolute; top:0 ;right: 0; border: 0; }
        .input-group-addon{ border-left: 1px solid #dcdcdc!important; border-right:0; padding: 16px; display: inline-block; position: absolute; top:0; right: 20px}
    </style>  
     
    <div class="tabs-new margin-top-40">
        <ul class="nav-new nav-tabs-new">
            <li class="active"><a href="<?=$remotelocation."doctorprofile_steps.php";?>" >Address</a></li>
            <li><a href="javascript:void(0);" >Personal Information </a></li>
            <li><a href="javascript:void(0);" >Speciality </a></li> 
        </ul>
    </div>
    <?php 
    $message = '';
    $email = $_SESSION["emp_email"];
    if(isset($_POST['action']) && !empty($_POST['action']) && $_POST['action'] == '_docprofilesteps'){
        $address1 = trim($_POST['address1']);
        $address2 = trim($_POST['address2']);
        $state = trim($_POST['state']);
        $dob = date("Y-m-d", strtotime($_POST['doctor_dob']));
        $phone = trim($_POST['telephone']);
        $city = trim($_POST['city']);
        $country = trim($_POST['country']);
        $zipcode = trim($_POST['zipcode']);
        $updateAddress = $db->Execute("update", "update " . DOCTOR . "  SET  street_address_line1='" . trim(mysql_real_escape_string($address1)) . "',street_address_line2='" . trim(mysql_real_escape_string($address2)) . "',doctor_state='" . trim(mysql_real_escape_string($state)) . "',country='" . trim(mysql_real_escape_string($country)) . "',zipcode='" . trim(mysql_real_escape_string($zipcode)) . "',doctor_dob='" . trim(mysql_real_escape_string($dob)) . "',doctor_telephone='" . trim(mysql_real_escape_string($phone)) ."',city='" . trim(mysql_real_escape_string($city)) ."' where `email`='" . $email . "'");
        echo"<script>window.location.href='doctorpersonal_detailtab.php'</script>";
    }else{
        $userdata = $db->Execute("select", "select  street_address_line1,street_address_line2,country,zipcode,doctor_state,doctor_dob,doctor_telephone,city FROM " . DOCTOR . " where email ='".$email."'");
       }
       //echo '<pre>'; print_r($userdata); exit();
    ?>
    <form id="accountForm" method="post" class="form-horizontal" action="<?php $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="action" value="_docprofilesteps">
        <div class="tab-content-new">
            <div class="tab-pane1">
                <div class="form-group">
                    <label class="col-xs-3 control-label">Dob</label>
                    <div class="col-xs-5">
                        <input type="text" id="doctor_dob" class="form-control required" readonly="readonly" name="doctor_dob" value="<?=(isset($userdata[0]['doctor_dob']) && !empty($userdata[0]['doctor_dob']) && intval($userdata[0]['doctor_dob']) > 0 ? date('m/d/Y', strtotime($userdata[0]['doctor_dob'])) : '');?>" />
                        <span class="input-group-addon">
                        <input type="button" class="cal_image"  onclick="displayCalendar(document.getElementById('doctor_dob'),'dd-mm-yyyy',this)">
                        </span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Telephone No.</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="telephone" value="<?=(isset($userdata[0]['doctor_telephone']) && !empty($userdata[0]['doctor_telephone']) ? $userdata[0]['doctor_telephone'] : '');?>" id="telephone" onkeypress="return isNumberKey(event)" maxlength="10"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Street Address Line 1</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="address1" rows="3" coloumn="3" id="address1"><?=(isset($userdata[0]['street_address_line1']) && !empty($userdata[0]['street_address_line1']) ? $userdata[0]['street_address_line1'] : '');?></textarea>
                    </div>
                </div>
                
                <div class="form-group">
                    <label class="col-xs-3 control-label">Street Address Line 2</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="address2" rows="3" coloumn="3" id="address2"><?=(isset($userdata[0]['street_address_line2']) && !empty($userdata[0]['street_address_line2']) ? $userdata[0]['street_address_line2'] : '');?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">City</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="city" id="city" value="<?=(isset($userdata[0]['city']) && !empty($userdata[0]['city']) ? $userdata[0]['city'] : '');?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">State</label>
                    <div class="col-xs-5" style="width:41.7%;">
                        <select class="form-control" name="state" id="state">
                            <option value="">Select a state</option>
                            <?php
                            if (isset($state_list) && !empty($state_list)) {
                                foreach ($state_list as $data) {
                                    if(isset($userdata[0]['doctor_state']) && $data['sta_id'] == $userdata[0]['doctor_state'] ){
                                        echo '<option value="'.$data['sta_id'].'" selected="selected" >'.$data['sta_name'].'</option>';
                                        
                                    }else{
                                        echo '<option value="'.$data['sta_id'].'">'.$data['sta_name'].'</option>';
                                    } 
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">Country</label>
                    <div class="col-xs-5" style="width:41.7%;">
                        <select class="form-control" name="country">
                            <option value="">Select a country</option>
                            <?php if(isset($userdata[0]['country'])){
                                 $selected="selected";
                            }else{
                                $selected = "";
                            } ?>
                            <option value="US" <?php echo $selected;?>>United States</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Zip Code</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="zipcode" value="<?=(isset($userdata[0]['zipcode']) && !empty($userdata[0]['zipcode']) ? $userdata[0]['zipcode'] :'' )?>" id="zipcode" maxlength="6" onkeypress="return isNumberKey(event)"/>
                    </div>
                </div>
                <div class="form-group" style="margin-top: 15px;">
                    <div class="col-xs-5 col-xs-offset-3">
                       <button  class="btn btn-primary btn-next" id="btn-next" name="submit" type="submit" style="margin-left:10px;">Save and continue</button></a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
<script>
 /*   jQuery("#btn-next").prop('disabled', true);
       var toValidate = jQuery('#datepicker, #telephone, #city ,#state,#country,#zipcode'),
            valid = false;
    toValidate.keyup(function () {
        if (jQuery(this).val().length > 0) {
            jQuery(this).data('valid', true);
        } else {
            jQuery(this).data('valid', false);
        }
        toValidate.each(function () {
            if (jQuery(this).data('valid') == true) {
                valid = true;
            } else {
                valid = false;
            }
        });
        if (valid === true) {
            jQuery("#btn-next").prop('disabled', false);
        } else {
            jQuery("#btn-next").prop('disabled', true);
        }
    }); */
</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>
<?php //require_once("includes/mfooter.php"); ?>