<?php
require_once("includes/top.php");
require_once("includes/doc_authentication.php");
?>
<?php require_once("includes/docheader.php"); ?>    
    <script src="<?=$remotelocation;?>includes/js/jquery.js"></script>
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.plugins.min.js"></script>			
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.revolution.min.js"></script>
    <script src="<?=$remotelocation;?>includes/js/medical.min.js"></script>	
    <script src="<?=$remotelocation;?>includes/js/jquery.validate.min.js"></script>
    <script src="<?=$remotelocation;?>includes/js/bootstrap.min.js"></script>    
    <div class="col-md-12 col-xs-12">
    <div class="container">
    <style type="text/css">
        #accountForm {
            margin-top: 15px;
        }
    </style>
    <div  class="tabs-new margin-top-40">
        <ul class="nav-new nav-tabs-new">
            <li><a href="javascript:void(0);" >Address</a></li>
            <li><a href="javascript:void(0);" >Personal Information </a></li>
            <li class="active"><a href="<?=$remotelocation."doctorspeciality_tab.php";?>" >Speciality </a></li>                  
        </ul>
    </div>
      <?php 
    $message = '';
    $email = $_SESSION["emp_email"];
    if(isset($_POST['action']) && !empty($_POST['action']) && $_POST['action'] == '_specialitytab'){
        $primary_speciality = trim($_POST['primary_speciality']);
        $secondary_speciality_1 = trim($_POST['secondary_speciality_1']);
        $secondary_speciality_2 = trim($_POST['secondary_speciality_2']);
        $secondary_speciality_3 = trim($_POST['secondary_speciality_3']);
        $secondary_speciality_4 = trim($_POST['secondary_speciality_4']);
        $all_secondary_speciality = trim($_POST['all_secondary_speciality']);
        $organization_legal_name = trim($_POST['organization_legal_name']);
        $organization_dba_name = trim($_POST['organization_dba_name']);
        $updateSpeciality = $db->Execute("update", "update " . DOCTOR . "  SET   primary_speciality='" . trim(mysql_real_escape_string($primary_speciality)) . "',secondary_speciality_1='" . trim(mysql_real_escape_string($secondary_speciality_1)) . "',secondary_speciality_2 ='" . trim(mysql_real_escape_string($secondary_speciality_2)) . "',secondary_speciality_3 ='" . trim(mysql_real_escape_string($secondary_speciality_3)) . "',secondary_speciality_4 ='" . trim(mysql_real_escape_string($secondary_speciality_4)) . "',all_secondary_speciality ='" . trim(mysql_real_escape_string($all_secondary_speciality)) . "',organization_legal_name ='" . trim(mysql_real_escape_string($organization_legal_name)) . "',organization_dba_name ='" . trim(mysql_real_escape_string($organization_dba_name)) . "' where `email`='" . $email . "'");
        echo"<script>window.location.href='doctordashboard.php'</script>";
    }else{
        $userdata = $db->Execute("select", "select  primary_speciality,secondary_speciality_1,secondary_speciality_2,secondary_speciality_3,secondary_speciality_4,all_secondary_speciality,organization_legal_name,organization_dba_name FROM " . DOCTOR . " where email ='".$email."'");
       }
    
    ?>

<form id="accountForm" method="post" class="form-horizontal" action="<?php $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="action" value="_specialitytab">
        <div class="tab-content-new">
         <div class="tab-pane1" id="others-tab">
             <div class="form-group">
                    <label class="col-xs-3 control-label">Primary Speciality</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="primary_speciality" rows="3" coloumn="3" id="primary_speciality"><?=(isset($userdata[0]['primary_speciality']) && !empty($userdata[0]['primary_speciality'])? $userdata[0]['primary_speciality'] : '');?></textarea>
                    </div>
                </div>
             <div class="form-group">
                    <label class="col-xs-3 control-label">Secondary Speciality 1</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="secondary_speciality_1" rows="3" coloumn="3" id="secondary_speciality_1"><?=(isset($userdata[0]['secondary_speciality_1']) && !empty($userdata[0]['secondary_speciality_1'])? $userdata[0]['secondary_speciality_1'] : '');?></textarea>
                    </div>
                </div>
             <div class="form-group">
                    <label class="col-xs-3 control-label">Secondary Speciality 2</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="secondary_speciality_2" rows="3" coloumn="3" id="secondary_speciality_2"><?=(isset($userdata[0]['secondary_speciality_2']) && !empty($userdata[0]['secondary_speciality_2'])? $userdata[0]['secondary_speciality_2'] : '');?></textarea>
                    </div>
                </div>
             <div class="form-group">
                    <label class="col-xs-3 control-label">Secondary Speciality 3</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="secondary_speciality_3" rows="3" coloumn="3" id="secondary_speciality_3"><?=(isset($userdata[0]['secondary_speciality_3']) && !empty($userdata[0]['secondary_speciality_3'])? $userdata[0]['secondary_speciality_3'] : '');?></textarea>
                    </div>
                </div>
             <div class="form-group">
                    <label class="col-xs-3 control-label">Secondary Speciality 4</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="secondary_speciality_4" rows="3" coloumn="3" id="secondary_speciality_4"><?=(isset($userdata[0]['secondary_speciality_4']) && !empty($userdata[0]['secondary_speciality_4'])? $userdata[0]['secondary_speciality_4'] : '');?></textarea>
                    </div>
                </div>
             <div class="form-group">
                    <label class="col-xs-3 control-label">All Secondary Speciality</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="all_secondary_speciality" rows="3" coloumn="3" id="all_secondary_speciality"><?=(isset($userdata[0]['all_secondary_speciality']) && !empty($userdata[0]['all_secondary_speciality'])? $userdata[0]['all_secondary_speciality'] : '');?></textarea>
                    </div>
                </div>
             <div class="form-group">
                    <label class="col-xs-3 control-label">Organisation Legal Name</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="organization_legal_name" id="organization_legal_name" value="<?=(isset($userdata[0]['organization_legal_name']) && !empty($userdata[0]['organization_legal_name']) ? $userdata[0]['organization_legal_name'] : '');?>"/>
                    </div>
                </div>
             <div class="form-group">
                    <label class="col-xs-3 control-label">Organisation DBA Name</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="organization_dba_name" id="organization_dba_name" value="<?=(isset($userdata[0]['organization_dba_name']) && !empty($userdata[0]['organization_dba_name']) ? $userdata[0]['organization_dba_name'] : '');?>"/>
                    </div>
                </div>
                <div class="form-group" style="margin-top: 15px;">
                    <div class="col-xs-5 col-xs-offset-3">
                        <a href="doctorpersonal_detailtab.php"><button  class="btn btn-primary btn-back" name="submit" type="button" id="btn-back" >Back</button></a>
                        <!--<a href="doctorpersonal_detailtab.php" data-toggle="tab"><button  class="btn btn-primary btn-back1" name="submit" type="submit" id="btn-back" >Back</button></a>-->
                        <button  class="btn btn-primary" name="submit" type="submit" id="submit" style="margin-left:10px;">Submit</button></a>
                    </div>
                </div>

            </div>
            </div>
</form>
    </div>
    </div>
<script>
   /* jQuery("#submit").prop('disabled', true);

    var submit = jQuery('#primary_speciality, #secondary_speciality_1, #secondary_speciality_2, #secondary_speciality_3 ,#secondary_speciality_4,#all_secondary_speciality,#organization_legal_name,#organization_dba_name'),
            action3 = false;
    submit.keyup(function () {
        if (jQuery(this).val().length > 0) {
            jQuery(this).data('action3', true);
        } else {
            jQuery(this).data('action3', false);
        }
        submit.each(function () {
            if (jQuery(this).data('action3') == true) {
                action3 = true;
            } else {
                action3 = false;
            }
        });
        if (action3 === true) {
            jQuery("#submit").prop('disabled', false);
        } else {
            jQuery("#submit").prop('disabled', true);
        }
    });*/
</script>
<script>
    $(document).ready(function () {
        $("#hourlyfees").keydown(function (e) {
            if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190]) !== -1 ||
                    (e.keyCode == 65 && (e.ctrlKey === true || e.metaKey === true)) ||
                    (e.keyCode >= 35 && e.keyCode <= 40)) {
                return;
            }
            if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
                e.preventDefault();
            }
        })
         });
</script>