<?php
require_once("includes/top.php");
require_once("includes/authentication.php");
if ($_POST['action'] == 'sendmessage') {
    $subject = trim($_POST['subject']);
    $receiverid = trim($_POST['receiver']);
    $senderid = trim($_POST['sender']);
    $message = trim($_POST['message']);
    //echo "insert into " . MESSAGES . " (message,sender_id,receiver_id,subject,date) values ('" . trim(mysql_real_escape_string($message)) . "' , '" .$senderid. "','" .$receiverid. "','" . trim(mysql_real_escape_string($subject)) . "','" . date('Y-m-d') . "')" ; exit;
    $saveMessage = $db->Execute("insert", "insert into " . MESSAGES . " (message,sender_id,receiver_id,subject,date,user_type) values ('" . trim(mysql_real_escape_string($message)) . "' , '" . $senderid . "','" . $receiverid . "','" . trim(mysql_real_escape_string($subject)) . "','" . date('Y-m-d') . "','PATIENT') ");
    $message = "Your message has been sent";
    echo $message;
    exit();
} elseif ($_POST['action'] == 'replymessage') {
    $replyid = trim($_POST['replyid']);
    $replytext = trim($_POST['replytext']);
    $replierid = trim($_POST['replierid']);
    //echo "insert into " . REPLY . " (message_id,replier_id,reply_text,date,reply_usertype) values ('" . $replyid . "' , '" .$replierid. "','" .trim(mysql_real_escape_string($replytext)). "','"  . date('Y-m-d') . "','PATIENT') "; exit;
    $saveReply = $db->Execute("insert", "insert into " . REPLY . " (message_id,replier_id,reply_text,date,reply_usertype) values ('" . $replyid . "' , '" . $replierid . "','" . trim(mysql_real_escape_string($replytext)) . "','" . date('Y-m-d') . "','PATIENT') ");
    $message = "Reply have been sent successfully ";
    echo $message;
    exit();
} elseif ($_POST['action'] == 'doctorreplymessage') {
    $replyid = trim($_POST['replyid']);
    $replytext = trim($_POST['replytext']);
    $replierid = trim($_POST['replierid']);
    //echo "insert into " . REPLY . " (message_id,replier_id,reply_text,date,reply_usertype) values ('" . $replyid . "' , '" .$replierid. "','" .trim(mysql_real_escape_string($replytext)). "','"  . date('Y-m-d') . "','PATIENT') "; exit;
    $saveReply = $db->Execute("insert", "insert into " . REPLY . " (message_id,replier_id,reply_text,date,reply_usertype) values ('" . $replyid . "' , '" . $replierid . "','" . trim(mysql_real_escape_string($replytext)) . "','" . date('Y-m-d') . "','DOCTOR') ");
    $message = "Reply sent successfully ";
    echo $message;
    exit();
} elseif ($_POST['action'] == '_getpatientimage') {
    $id = trim($_POST['id']);
    $gender = trim($_POST['gender']);
    if ($_POST['gender'] == 'm') {
        $getImage = $db->Execute("select", "select patient_male as img  FROM " . BODYPARTS . " where bodyparts_id = '" . $id . "' ");
    } elseif ($_POST['gender'] == 'f') {
        $getImage = $db->Execute("select", "select patient_female as img FROM " . BODYPARTS . " where bodyparts_id = '" . $id . "' ");
    }
    $imgPath =  $remotelocation."includes/images/bodyparts/".$getImage[0]['img'];
    echo "<img src='".$imgPath."' border='0' style='width:250px;height:350px;' />";
    exit();
} elseif ($_POST['action'] == '_getsymptoms') {
    $id = trim($_POST['id']);
    $getData = $db->Execute("select", "select DISTINCT(symptom_descr),symptom_id  FROM " . SYMPTOMS . " where bodyparts_id = '".$id."' ");?>
    <option value = "">Select State</option>
    <?php
    foreach ($getData as $bodysymptoms) {
        ?>
    <option value="<?php echo $bodysymptoms['symptom_id']; ?>"><?php echo $bodysymptoms['symptom_descr']; ?></option>
        <?php
    }
}
?>