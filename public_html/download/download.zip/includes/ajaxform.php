<?php
require_once("top.php");
require_once("database_tables.php");
 if($_POST){
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$emailaddress = $_POST['emailaddress'];
$phonenumber = $_POST['phonenumber']; 
$gender=$_POST['gender'];
$appointmentdate = $_POST['appointmentdate'];
$appointment = date('Y-m-d H:i:s', strtotime($appointmentdate));
$message=$_POST['message'];
$from = "email@example.com";
$subject="Your appointment";
//$request_date = $_POST['request_date'];
$inserteddata = $db->Execute("insert", "insert into" .' '.APPOINTMENT. "(first_name,last_name,emailaddress,phone_number,appointment_date,gender,message) values ('$firstname', '$lastname', '$emailaddress','$phonenumber','$appointment','$gender','$message')");
if($inserteddata){
      mail($emailaddress, $subject, $message, $from);
 echo "An Email regarding your appointment has been sent to you ";
 exit;
}
 else {
echo "There are some error requesting your appointment";
exit;
}
}
?>
