<?php
@ini_set('session.gc_maxlifetime', '3600');
set_time_limit(0);
ini_set('memory_limit', '256M');
$remotelocation="http://infinity-stores.co.uk/cmforyou/";
$host = "localhost"; // Host name
$username = "sanjeevu_pradeep"; // Mysql username
$password = "pass@123"; // Mysql password
$db_name = "sanjeevu_cmforyou"; // Database name
date_default_timezone_set('Asia/Calcutta');
define("DOCUMENT_PATHS",$_SERVER['DOCUMENT_ROOT']."/help_docs");
define("ROOT_PATHS",$_SERVER['DOCUMENT_ROOT']."/latest/images");
?>

