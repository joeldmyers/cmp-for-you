<?php

define('PATIENTS', 'tbl_patients');
define('STATES', 'tbl_states');   
define('APPOINTMENT', 'tbl_appointments');
define('BODYPARTS', 'tbl_bodyparts');
define('TRANSACTIONS', 'tbl_transactions');
define('MEDIC', 'medic');
define('MESSAGES', 'tbl_messages');
define('REPLY', 'tbl_messages_reply');
define('DOCTOR', 'tbl_doctor');
define('SYMPTOMS', 'tbl_symptoms');
?>
