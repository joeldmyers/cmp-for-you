<footer id="footer">
       <div class="bottom-sec-footer">
            	<div class="col-md-12">
                    <div class="footer-widget">
                        <ul class="footer-nav list-unstyled clearfix">
                            <li><a href="#.">Home</a></li>|
                            <li><a href="#.">Doctors</a></li>|
                            <li><a href="#.">About US</a></li>|
                            <li><a href="#.">Services</a></li>|
                            <li><a href="#.">Why US</a></li>|
                            <li><a href="#.">Medical Care</a></li>|
                            <li><a href="#.">Specilaties</a></li>|
                            <li><a href="#.">Support</a></li>
                            
                        </ul>
                    </div>
                </div><div class="clearfix"></div>
                
                <div class="col-md-12"> Copyright &copy; <?php echo date('Y');?> Custom Medical Services . All right reserved. | Designed &amp; Developed by <a href="http://www.dreamsoft4u.com/" target="_blank">Dreamsoft4u</a></div>
                
      </div>
    </footer>
    </div><!--end #wrapper-->