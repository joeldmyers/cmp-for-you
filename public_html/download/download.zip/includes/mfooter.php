<!-- FOOTER -->
    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-6"></div>
                <div class="col-md-6 text-right"></div>
            </div>
        </div>
    </footer>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="<?=$remotelocation."includes/js/bootstrap.min.js"; ?>"></script>
    <script src="<?=$remotelocation."includes/js/docs.min.js"; ?>" ></script>
    <script src="<?=$remotelocation."includes/js/public.js"; ?>" ></script>