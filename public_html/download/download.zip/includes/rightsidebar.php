 <div class="col-md-3 col-xs-12">
                <div class="recentbar">
                    <h4>RECENT ACTIVITIES</h4>
                    <ul class="list">
                        <li><a href="#"><i class="fa fa-comment-o"></i> You have 0 new message(s)</a> </li>
                        <li><a href="#"><i class="fa fa-calendar"></i> You have 0 Appointments</a> </li>
                        <li><a href="#"><i class="fa fa-comment-o"></i> You have 0 new message(s)</a> </li>
                        <li><a href="#"><i class="fa fa-comment-o"></i> You have 0 new message(s)</a> </li>
                    </ul>
                </div>
            </div>
        </div>