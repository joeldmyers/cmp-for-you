<?php
require_once("includes/top.php");
require_once("includes/authentication.php");
?>
    <?php require_once("includes/mheader.php"); ?>    
    <script src="<?=$remotelocation;?>includes/js/jquery.js"></script>
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.plugins.min.js"></script>			
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.revolution.min.js"></script>
    <script src="<?=$remotelocation;?>includes/js/medical.min.js"></script>	
    <script src="<?=$remotelocation;?>includes/js/jquery.validate.min.js"></script>
    <!---<script src="<?=$remotelocation;?>includes/js/bootstrap.min.js"></script>--->
<div class="col-md-12 col-xs-12">
    <div class="container">
    <style type="text/css">
        #accountForm {
            margin-top: 15px;
        }
    </style>
    <div class="tabs-new margin-top-40">
        <ul class="nav-new nav-tabs-new">
            <li><a href="javascript:void(0);" >Address</a></li>
            <li><a href="javascript:void(0);" >Problems </a></li>
            <li class="active"><a href="<?=$remotelocation."medication_tab.php"; ?>" >Medication </a></li>
            <li><a href="javascript:void(0);" >Allergies </a></li>
            <li><a href="javascript:void(0);" >Others </a></li>  
        </ul>
    </div>
    
    <?php 
    $message = '';
    $email = $_SESSION["emp_email"];
    if(isset($_POST['action']) && !empty($_POST['action']) && $_POST['action'] == '_medicationtab'){
        $medication1 = trim($_POST['medication1']);
        $medication2 = trim($_POST['medication2']);
        $medication3 = trim($_POST['medication3']);
        $updateMedication = $db->Execute("update", "update " . PATIENTS . "  SET  patient_medication1='" . trim(mysql_real_escape_string($medication1)) . "',patient_medication2='" . trim(mysql_real_escape_string($medication2)) . "',patient_medication3='" . trim(mysql_real_escape_string($medication3)) . "' where `patient_email`='" . $email . "'");
        echo"<script>window.location.href='allergies_tab.php'</script>";
    }else{
        $userdata = $db->Execute("select", "select  patient_medication1,patient_medication2,patient_medication3 FROM " . PATIENTS . " where patient_email ='".$email."'");
       }
    
    ?>

<form id="accountForm" method="post" class="form-horizontal" action="<?php $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="action" value="_medicationtab">
        <div class="tab-content-new">
         <div class="tab-pane1" id="medication-tab">
                <div class="form-group">
                    <label class="col-xs-3 control-label">Medications1</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" id="medication1" name="medication1" rows="3" coloumn="3"><?=(isset($userdata[0]['patient_medication1']) && !empty($userdata[0]['patient_medication1'])? $userdata[0]['patient_medication1'] : '');?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">Medication2</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="medication2" rows="3" coloumn="3"><?=(isset($userdata[0]['patient_medication2']) && !empty($userdata[0]['patient_medication2'])? $userdata[0]['patient_medication2'] : '');?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">Medication3</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="medication3" rows="3" coloumn="3"><?=(isset($userdata[0]['patient_medication3']) && !empty($userdata[0]['patient_medication3'])? $userdata[0]['patient_medication3'] : '');?></textarea>
                    </div>
                </div>

                <div class="form-group" style="margin-top: 15px;">
                    <div class="col-xs-5 col-xs-offset-3">
                        <a href="problems_tab.php"><button  class="btn btn-primary btn-back" name="submit" type="button" id="btn-back" >Back</button></a>
                        <!--<a href="problems_tab.php"><button  class="btn btn-primary btn-back1" name="submit"  type="submit" id="btn-back" >Back</button></a>-->
                        <a href="allergies_tab.php"><button  class="btn btn-primary btn-next" name="submit"  type="submit" id="btn-next2" style="margin-left:10px;">Save and continue</button></a>
                    </div>
                </div>
            </div>
            </div>
    </form>
    
    <div class="col-md-12 col-xs-12" style="min-height:200px;"></div>
    </div>
</div>    
<script>
    /*
    jQuery("#btn-next2").prop('disabled', true);

    var mediTab = jQuery('#medication1'),
            action1 = false;
    mediTab.keyup(function () {
        if (jQuery(this).val().length > 0) {
            jQuery(this).data('action1', true);
        } else {
            jQuery(this).data('action1', false);
        }
        mediTab.each(function () {
            if (jQuery(this).data('action1') == true) {
                action1 = true;
            } else {
                action1 = false;
            }
        });
        if (action1 === true) {
            jQuery("#btn-next2").prop('disabled', false);
        } else {
            jQuery("#btn-next2").prop('disabled', true);
        }
    });*/
</script>
<style>
    .home{
        background: #fff !important;
    }
    
</style>
<?php require_once("includes/mfooter.php"); ?>