<?php
require_once("includes/top.php");
require_once("includes/authentication.php");
?>
<?php require_once("includes/mheader.php"); ?>    
    <script src="<?=$remotelocation;?>includes/js/jquery.js"></script>
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.plugins.min.js"></script>			
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.revolution.min.js"></script>
    <script src="<?=$remotelocation;?>includes/js/medical.min.js"></script>	
    <script src="<?=$remotelocation;?>includes/js/jquery.validate.min.js"></script>
    <!---<script src="<?=$remotelocation;?>includes/js/bootstrap.min.js"></script>--->    
    <div class="col-md-12 col-xs-12">
    <div class="container">
    <style type="text/css">
        #accountForm {
            margin-top: 15px;
        }
    </style>
    <div  class="tabs-new margin-top-40">
        <ul class="nav-new nav-tabs-new">
            <li><a href="javascript:void(0);" >Address</a></li>
            <li><a href="javascript:void(0);" >Problems </a></li>
            <li><a href="javascript:void(0);" >Medication </a></li>
            <li><a href="javascript:void(0);" >Allergies </a></li>
            <li class="active"><a href="<?=$remotelocation."others_tab.php"; ?>" >Others </a></li>                  
        </ul>
    </div>
      <?php 
    $message = '';
    $email = $_SESSION["emp_email"];
    if(isset($_POST['action']) && !empty($_POST['action']) && $_POST['action'] == '_otherstab'){
        $insurance = trim($_POST['insurance']);
        $medicare = trim($_POST['medicare']);
        $medicaid = trim($_POST['medicaid']);
        $vainsurance = trim($_POST['vainsurance']);
        $hourlyfees = trim($_POST['hourlyfees']);
        $summary = trim($_POST['summary']);
        $updateOthers = $db->Execute("update", "update " . PATIENTS . "  SET   patient_is_insured='" . trim(mysql_real_escape_string($insurance)) . "',patient_is_medicare='" . trim(mysql_real_escape_string($medicare)) .  "', patient_has_medicarid='" . trim(mysql_real_escape_string($medicaid)) .  "',patient_has_vainsurance ='" . trim(mysql_real_escape_string($vainsurance)) . "',patient_pay_hour_fees ='" . trim(mysql_real_escape_string($hourlyfees)) . "',patient_healthsummary ='" . trim(mysql_real_escape_string($summary)) . "',patient_isprofilecomplete = 1 where `patient_email`='" . $email . "'");
        echo"<script>window.location.href='patientdashboard.php'</script>";
    }else{
        $userdata = $db->Execute("select", "select  patient_is_insured,patient_is_medicare,patient_has_medicarid,patient_has_vainsurance,patient_pay_hour_fees,patient_healthsummary FROM " . PATIENTS . " where patient_email ='".$email."'");
       }
    
    ?>

<form id="accountForm" method="post" class="form-horizontal" action="<?php $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="action" value="_otherstab">
        <div class="tab-content-new">
         <div class="tab-pane1" id="others-tab">
                <div class="form-group">
                    <label class="col-xs-3 control-label">Insurance Status</label>
                    <div class="col-xs-5" style="width:22%;">
                        <select class="form-control" name="insurance" id="insurance">
                            <option value="">Please Select</option>
                            <option value="1"<?=($userdata[0]['patient_is_insured'] == '1' ? 'selected="selected"' : '');?>>Yes</option>
                            <option value="2"<?=($userdata[0]['patient_is_insured'] == '2' ? 'selected="selected"' : '');?>>No</option>
                            <option value="3"<?=($userdata[0]['patient_is_insured'] == '3' ? 'selected="selected"' : '');?>>Don't Know</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Medicare</label>
                    <div class="col-xs-5" style="width:22%;">
                        <select class="form-control" name="medicare" id="medicare">
                            <option value="">Please Select</option>
                            <option value="1"<?=(isset($userdata[0]['patient_is_medicare']) && $userdata[0]['patient_is_medicare'] == '1' ? 'selected="selected"' : '');?>>Yes</option>
                            <option value="2"<?=(isset($userdata[0]['patient_is_medicare']) && $userdata[0]['patient_is_medicare'] == '1' ? 'selected="selected"' : '');?>>No</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Medicaid</label>
                    <div class="col-xs-5" style="width:22%;">
                        <select class="form-control" name="medicaid" id="medicaid">
                            <option value="">Please Select</option>
                            <option value="1"<?=(isset($userdata[0]['patient_has_medicarid']) && $userdata[0]['patient_has_medicarid'] == '1' ? 'selected="selected"' : '');?>>Yes</option>
                            <option value="2"<?=(isset($userdata[0]['patient_has_medicarid']) && $userdata[0]['patient_has_medicarid'] == '2' ? 'selected="selected"' : '');?>>No</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">VA Insurance</label>
                    <div class="col-xs-5" style="width:22%;">
                        <select class="form-control" name="vainsurance" id="vainsurance">
                            <option value="">Please Select</option>
                            <option value="1"<?=(isset($userdata[0]['patient_has_vainsurance']) && $userdata[0]['patient_has_vainsurance'] == '1' ? 'selected="selected"' : '');?>>Yes</option>
                            <option value="2"<?=(isset($userdata[0]['patient_has_vainsurance']) && $userdata[0]['patient_has_vainsurance'] == '2' ? 'selected="selected"' : '');?>>No</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">How much patient is willing to pay per hour for service?</label>
                    <div class="col-xs-5" style="width:22%;">
                        <input type="text" class="form-control" placeholder="" maxlength="5" name="hourlyfees" onkeypress="return isNumberKey(event)" id="hourlyfees" value="<?=(isset($userdata[0]['patient_pay_hour_fees']) && !empty($userdata[0]['patient_pay_hour_fees']) ? $userdata[0]['patient_pay_hour_fees'] : '' )?>" />
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">Summary of health problems</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="summary" rows="3" coloumn="3"><?=(isset($userdata[0]['patient_healthsummary']) && !empty($userdata[0]['patient_healthsummary']) ? $userdata[0]['patient_healthsummary'] :'' )?></textarea>
                    </div>
                </div>

                <div class="form-group" style="margin-top: 15px;">
                    <div class="col-xs-5 col-xs-offset-3">
                        <a href="allergies_tab.php"><button  class="btn btn-primary btn-back" name="submit" type="button" id="btn-back" >Back</button></a>
                        <!--<a href="allergies_tab.php"><button  class="btn btn-primary btn-back" name="submit" type="submit" id="btn-back" >Back</button></a>-->
                        <!--<a href="profile_steps.php"><button  class="btn btn-primary btn-back" name="submit" type="button" id="btn-back" >Back</button></a>-->
                        <button  class="btn btn-primary" name="submit" type="submit" id="submit" style="margin-left:10px;">Submit</button></a>
                    </div>
                </div>

            </div>
            </div>
</form>
    </div>
    </div>
<script>
    /*jQuery("#submit").prop('disabled', true);

    var submit = jQuery('#datepicker, #telephone, #address, #city ,#state,#country,#zipcode,#painarea,#painlevel,#tearmentplace,#symptoms1,#medication1,#allergies,#insurance,#medicaid,#medicare,#vainsurance,#hourlyfees'),
            action3 = false;
    submit.keyup(function () {
        if (jQuery(this).val().length > 0) {
            jQuery(this).data('action3', true);
        } else {
            jQuery(this).data('action3', false);
        }
        submit.each(function () {
            if (jQuery(this).data('action3') == true) {
                action3 = true;
            } else {
                action3 = false;
            }
        });
        if (action3 === true) {
            jQuery("#submit").prop('disabled', false);
        } else {
            jQuery("#submit").prop('disabled', true);
        }
    });*/
</script>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>
<style>
    .home{
        background: #fff !important;
    }
    
</style>
<?php require_once("includes/mfooter.php"); ?>