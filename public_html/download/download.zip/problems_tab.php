<?php
require_once("includes/top.php");
require_once("includes/authentication.php");
global $db;
$bodyparts = $db->Execute("select", "select bodyparts_id,patient_bodyparts FROM " . BODYPARTS);
?>
<?php require_once("includes/mheader.php"); ?>    
<script src="<?= $remotelocation; ?>includes/js/jquery.js"></script>
<script src="<?= $remotelocation; ?>includes/js/jquery.themepunch.plugins.min.js"></script>			
<script src="<?= $remotelocation; ?>includes/js/jquery.themepunch.revolution.min.js"></script>
<script src="<?= $remotelocation; ?>includes/js/medical.min.js"></script>	
<script src="<?= $remotelocation; ?>includes/js/jquery.validate.min.js"></script>
<!---<script src="<?= $remotelocation; ?>includes/js/bootstrap.min.js"></script>--->    
<div class="col-md-12 col-xs-12">

    <div class="container">
        <style type="text/css">
            #accountForm {
                margin-top: 15px;
            }
        </style>
        <div  class="tabs-new margin-top-40">
            <ul class="nav-new nav-tabs-new">
                <li><a href="javascript:void(0);" >Address</a></li>
                <li class="active"><a href="<?= $remotelocation . "problems_tab.php"; ?>" >Problems </a></li>
                <li><a href="javascript:void(0);" >Medication </a></li>
                <li><a href="javascript:void(0);" >Allergies </a></li>
                <li><a href="javascript:void(0);" >Others </a></li>  
            </ul>
        </div>
        <?php
        $message = '';
        $email = $_SESSION["emp_email"];
        if (isset($_POST['action']) && !empty($_POST['action']) && $_POST['action'] == '_problemstab') {
            $painarea = trim($_POST['painarea']);
            $painlevel = trim($_POST['painlevel']);
            $treatmentplace = trim($_POST['tearmentplace']);
            $symptoms1 = trim($_POST['symptoms1']);
            $symptoms2 = trim($_POST['symptoms2']);
            $symptoms3 = trim($_POST['symptoms3']);
            $bodysymptoms = trim($_POST['bodysymptoms']);
            $updateProblems = $db->Execute("update", "update " . PATIENTS . "  SET   patient_body_pain_area='" . trim(mysql_real_escape_string($painarea)) . "',patient_body_pain_level='" . trim(mysql_real_escape_string($painlevel)) . "',patient_teatment_place='" . trim(mysql_real_escape_string($treatmentplace)) . "',patient_symptoms1='" . trim(mysql_real_escape_string($symptoms1)) . "',patient_symptoms2='" . trim(mysql_real_escape_string($symptoms2)) . "',patient_symptoms3='" . trim(mysql_real_escape_string($symptoms3)) . "',patient_bodysymptoms='" . trim(mysql_real_escape_string($bodysymptoms)) . "' where `patient_email`='" . $email . "'");
            echo"<script>window.location.href='medication_tab.php'</script>";
        } else {
            $userdata = $db->Execute("select", "select  patient_gender,patient_body_pain_area,patient_body_pain_level,patient_teatment_place,patient_symptoms1,patient_symptoms2,patient_symptoms3,patient_bodysymptoms FROM " . PATIENTS . " where patient_email ='" . $email . "'");
        }
        ?>
        <form id="accountForm" method="post" class="form-horizontal col-md-9" action="<?php $_SERVER['PHP_SELF']; ?>">
            <input type="hidden" name="action" value="_problemstab">
            <input type="hidden" name="gender" id="gender" value="<?php echo $userdata[0]['patient_gender'] ?>">
            <div class="tab-content-new">
                <div class="tab-pane1" id="problems-tab">
                    <div class="form-group">
                        <label class="col-xs-3 control-label">Body Pain Area</label>
                        <div class="col-xs-5" style="width:41.6%%;">
                            <select class="form-control" name="painarea" id="painarea" onchange="return getsymptoms(this.value);">
                                <option value="">Select Body Area</option>
                                <?php
                                foreach ($bodyparts as $value) {

                                    if (isset($userdata[0]['patient_body_pain_area']) && $value['bodyparts_id'] == $userdata[0]['patient_body_pain_area']) {
                                        echo '<option value="' . $value['bodyparts_id'] . '" selected="selected" >' . $value['patient_bodyparts'] . '</option>';
                                    } else {
                                        echo '<option id="' . $value['bodyparts_id'] . '" value="' . $value['bodyparts_id'] . '">' . $value['patient_bodyparts'] . '</option>';
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-xs-3 control-label">Body Pain Level</label>
                        <div class="col-xs-5" style="width:41.6%;">
                            <input type="number" class="form-control" min="1" max="10" name="painlevel" value="<?= (isset($userdata[0]['patient_body_pain_level']) && !empty($userdata[0]['patient_body_pain_level']) ? $userdata[0]['patient_body_pain_level'] : ''); ?>" id="painlevel"/>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="col-xs-3 control-label">Body Symptoms</label>
                        <div class="col-xs-5" style="width:41.6%%;">
                            <select class="form-control" name="bodysymptoms" id="bodysymptoms">
                                <option value="">Select Part</option>
                                
                                <?php if(isset($userdata[0]['patient_bodysymptoms']) && !empty($userdata[0]['patient_bodysymptoms'])){
                                    $bodypartsdata = $db->Execute("select", "select  symptom_id,symptom_descr FROM " . SYMPTOMS . " where symptom_id  ='" . $userdata[0]['patient_bodysymptoms'] . "'");
                                    echo '<option value="' . $bodypartsdata[0]['symptom_id'] . '" selected="selected" >' . $bodypartsdata[0]['symptom_descr'] . '</option>';
                                }
                                    ?>
                              
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-xs-3 control-label">Treatment Place</label>
                        <div class="col-xs-5" style="width:41.6%%;">
                            <select class="form-control" name="tearmentplace" id="tearmentplace">
                                <option value="">Select Place For Treatment</option>
                                <option value="home"<?= ($userdata[0]['patient_teatment_place'] == 'home' ? 'selected="selected"' : ''); ?>>At Home</option>
                                <option value="nursinghome"<?= ($userdata[0]['patient_teatment_place'] == 'nursinghome' ? 'selected="selected"' : ''); ?>>Nursing Home</option>
                                <option value="docoffice"<?= ($userdata[0]['patient_teatment_place'] == 'docoffice' ? 'selected="selected"' : ''); ?>>Doctor's Office</option>
                                <option value="clinic"<?= ($userdata[0]['patient_teatment_place'] == 'clinic' ? 'selected="selected"' : ''); ?>>Clinic</option>
                                <option value="hospital"<?= ($userdata[0]['patient_teatment_place'] == 'hospital' ? 'selected="selected"' : ''); ?>>Hospital</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-xs-3 control-label">Primary Symptoms</label>
                        <div class="col-xs-5">
                            <textarea class="form-control" name="symptoms1" rows="3" coloumn="3" id="symptoms1"><?= (isset($userdata[0]['patient_symptoms1']) && !empty($userdata[0]['patient_symptoms1']) ? $userdata[0]['patient_symptoms1'] : ''); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-xs-3 control-label">Secondary Symptoms</label>
                        <div class="col-xs-5">
                            <textarea class="form-control" name="symptoms2" rows="3" coloumn="3"><?= (isset($userdata[0]['patient_symptoms2']) && !empty($userdata[0]['patient_symptoms2']) ? $userdata[0]['patient_symptoms2'] : ''); ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="col-xs-3 control-label">Tertiary Symptoms</label>
                        <div class="col-xs-5">
                            <textarea class="form-control" name="symptoms3" rows="3" coloumn="3"><?= (isset($userdata[0]['patient_symptoms3']) && !empty($userdata[0]['patient_symptoms3']) ? $userdata[0]['patient_symptoms3'] : ''); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group" style="margin-top: 15px;">
                        <div class="col-xs-5 col-xs-offset-3">
                            <a href="profile_steps.php"><button  class="btn btn-primary btn-back" name="submit" type="button" id="btn-back" >Back</button></a>
                            <a href="medication_tab.php"><button  class="btn btn-primary btn-next1" name="submit" type="submit" id="btn-next1" style="margin-left:10px;">Save and continue</button></a>
                        </div>
                    </div>

                </div>
            </div>
        </form>
        <?php $result = $db->Execute("select", "select patient_male,patient_female FROM " . BODYPARTS ." where bodyparts_id ='".$userdata[0]['patient_body_pain_area']."'");?>
        <div class="col-md-3 pull-right" id="avatarholder">
<!--             <?php //if (isset($userdata[0]['patient_gender']) && empty($userdata[0]['patient_body_pain_area']) && $userdata[0]['patient_gender'] == 'm') { ?>
                <img src="<?php //echo $remotelocation . "includes/images/bodyparts/default-man.jpg" ?>" width="100%" height="60%">
            <?php //} elseif (isset($userdata[0]['patient_gender']) && empty($userdata[0]['patient_body_pain_area']) && $userdata[0]['patient_gender'] == 'f') { ?>
                <img src="<?php //echo $remotelocation . "includes/images/bodyparts/default-woman.jpg" ?>" width="100%" height="60%">-->
            <?php  if (isset($userdata[0]['patient_body_pain_area']) && !empty($userdata[0]['patient_body_pain_area']) && $userdata[0]['patient_gender'] == 'm') { ?>
                <img src="<?php echo $remotelocation . "includes/images/bodyparts/" . $result[0]['patient_male'] ?>" width="100%" height="60%"> 
            <?php } elseif (isset($userdata[0]['patient_body_pain_area']) && !empty($userdata[0]['patient_body_pain_area']) && $userdata[0]['patient_gender'] == 'f') { ?>
                <img src="<?php echo $remotelocation . "includes/images/bodyparts/" . $result[0]['patient_female'] ?>" width="100%" height="60%"> 
            <?php } ?>
        </div>
    </div>  
</div>
<script>
    /*
     jQuery("#btn-next1").prop('disabled', true);
     
     var probTab = jQuery('#painarea,#painlevel,#tearmentplace,#symptoms1'),
     action = false;
     probTab.keyup(function () {
     if (jQuery(this).val().length > 0) {
     jQuery(this).data('action', true);
     } else {
     jQuery(this).data('action', false);
     }
     probTab.each(function () {
     if (jQuery(this).data('action') == true) {
     action = true;
     } else {
     action = false;
     }
     });
     if (action === true) {
     jQuery("#btn-next1").prop('disabled', false);
     } else {
     jQuery("#btn-next1").prop('disabled', true);
     }
     });*/
</script>
<script>
    function changeimage(id) {
        var action = "_getpatientimage";
        var gender = $("#gender").val();
        var dataString = 'id=' + id + '&action=' + action + '&gender=' + gender;
        document.getElementById("avatarholder").innerHTML = '<img src="<?php echo $remotelocation."includes/images/loading.gif"; ?>" border="0" style="margin-top:50px;" />';
        $.ajax({
            type: "POST",
            url: "<?= $remotelocation . "getajaxdata.php" ?>",
            data: dataString,
            dataType: 'html',
            success: function (data) {
                //  var response = $.parseJSON(data);
              
                $("#avatarholder").html(data);
            }
        });
    }

function getsymptoms(id){
       var action = '_getsymptoms'; 
       var dataString = 'id=' + id + '&action=' + action;
      $.ajax({
            type: "POST",
            url: "<?= $remotelocation . "getajaxdata.php" ?>",
            data: dataString,
            success: function (data) {
             $("#bodysymptoms").html(data);
              changeimage(id);
            }
        });
    
}
</script>
<style>
    .home{
        background-color: #fff !important;
    }
    
</style>
<?php require_once("includes/mfooter.php"); ?>