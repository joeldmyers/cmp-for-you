<?php
require_once("includes/top.php");
require_once("includes/authentication.php");
global $db;
$state_list = $db->Execute("select", "select sta_id,sta_name FROM " . STATES . " where sta_couid = '1'");
//$state_list = $db->Execute("select", "select sta_id,sta_name FROM " . STATES . " where sta_couid = '1'");
// echo "<pre/>"; print_r($state_list); exit;
?>
<?php require_once("includes/mheader.php"); ?>    
    <script src="<?=$remotelocation;?>includes/js/jquery.js"></script>
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.plugins.min.js"></script>			
    <script src="<?=$remotelocation;?>includes/js/jquery.themepunch.revolution.min.js"></script>
    <script src="<?=$remotelocation;?>includes/js/medical.min.js"></script>	
    <script src="<?=$remotelocation;?>includes/js/jquery.validate.min.js"></script>
<!--    <script src="<?=$remotelocation;?>includes/js/bootstrap.min.js"></script>-->
    <script src="<?=$remotelocation;?>includes/js/dhtmlgoodies_calendar.js?random=20060118"></script>
    
<div class="col-md-12 col-xs-12">
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="<?=$remotelocation;?>includes/css/dhtmlgoodies_calendar.css?random=20051112">
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<div class="container">
    <style type="text/css">
        #accountForm {
            margin-top: 15px;
        }
        .cal_image {  background: url(includes/images/calendra.gif) no-repeat;  width: 20px; height: 20px;margin-top: 10px !important;}
        .monthYearPicker{    color:#FFFFFF !important;}
        #calendarDiv table{ clear: both;}
       .cal_image{ position: absolute; top:0 ;right: 0; border: 0; }
        .input-group-addon{ border-left: 1px solid #dcdcdc!important; border-right:0; padding: 16px; display: inline-block; position: absolute; top:0; right: 20px}
    </style>  
     
    <div class="tabs-new margin-top-40">
        <ul class="nav-new nav-tabs-new">
            <li class="active"><a href="<?=$remotelocation."profile_steps.php";?>" >Address</a></li>
            <li><a href="javascript:void(0);" >Problems </a></li>
            <li><a href="javascript:void(0);" >Medication </a></li>
            <li ><a href="javascript:void(0);" >Allergies </a></li>
            <li><a href="javascript:void(0);" >Others </a></li>  
        </ul>
    </div>
    <?php 
    $message = '';
    $email = $_SESSION["emp_email"];
    if(isset($_POST['action']) && !empty($_POST['action']) && $_POST['action'] == '_addresstab'){
        $address = trim($_POST['address']);
        $state = trim($_POST['state']);
        $dob = date("Y-m-d", strtotime($_POST['patient_dob']));
        $phone = trim($_POST['telephone']);
        $city = trim($_POST['city']);
        $country = trim($_POST['country']);
        $zipcode = trim($_POST['zipcode']);
        $updateAddress = $db->Execute("update", "update " . PATIENTS . "  SET  patient_streetaddress='" . trim(mysql_real_escape_string($address)) . "',paitent_state='" . trim(mysql_real_escape_string($state)) . "',patient_city='" . trim(mysql_real_escape_string($city)) . "',patient_country='" . trim(mysql_real_escape_string($country)) . "',patient_zipcode='" . trim(mysql_real_escape_string($zipcode)) . "',patient_dob='" . trim(mysql_real_escape_string($dob)) . "',patient_telephone='" . trim(mysql_real_escape_string($phone)) ."' where `patient_email`='" . $email . "'");
        echo"<script>window.location.href='problems_tab.php'</script>";
    }else{
        $userdata = $db->Execute("select", "select  patient_streetaddress,paitent_state,patient_city,patient_country,patient_zipcode,patient_dob,patient_telephone FROM " . PATIENTS . " where patient_email ='".$email."'");
       }
       //echo '<pre>'; print_r($userdata); exit();
    ?>
    <form id="accountForm" method="post" class="form-horizontal" action="<?php $_SERVER['PHP_SELF']; ?>">
        <input type="hidden" name="action" value="_addresstab">
        <div class="tab-content-new">
            <div class="tab-pane1">
                <div class="form-group">
                    <label class="col-xs-3 control-label">Dob</label>
                    <div class="col-xs-5">
                        <input type="text" id="patient_dob" class="form-control required" readonly="readonly" name="patient_dob" value="<?=(isset($userdata[0]['patient_dob']) && !empty($userdata[0]['patient_dob']) && intval($userdata[0]['patient_dob']) > 0 ? date('m/d/Y', strtotime($userdata[0]['patient_dob'])) : '');?>" />
                        <span class="input-group-addon">
                        <input type="button" class="cal_image"  onclick="displayCalendar(document.getElementById('patient_dob'),'dd-mm-yyyy',this)">
                        </span>
                    </div>            
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Telephone No.</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="telephone" value="<?=(isset($userdata[0]['patient_telephone']) && !empty($userdata[0]['patient_telephone']) ? $userdata[0]['patient_telephone'] : '');?>" onkeypress="return isNumberKey(event)" id="telephone" maxlength="10"/>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Address</label>
                    <div class="col-xs-5">
                        <textarea class="form-control" name="address" rows="3" coloumn="3" id="address"><?=(isset($userdata[0]['patient_streetaddress']) && !empty($userdata[0]['patient_streetaddress']) ? $userdata[0]['patient_streetaddress'] : '');?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">City</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="city" id="city" value="<?=(isset($userdata[0]['patient_city']) && !empty($userdata[0]['patient_city']) ? $userdata[0]['patient_city'] : '');?>"/>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">State</label>
                    <div class="col-xs-5" style="width:41.7%;">
                        <select class="form-control" name="state" id="state">
                            <option value="">Select a state</option>
                            <?php
                            if (isset($state_list) && !empty($state_list)) {
                                foreach ($state_list as $data) {
                                    if(isset($userdata[0]['paitent_state']) && $data['sta_id'] == $userdata[0]['paitent_state'] ){
                                        echo '<option value="'.$data['sta_id'].'" selected="selected" >'.$data['sta_name'].'</option>';
                                        
                                    }else{
                                        echo '<option value="'.$data['sta_id'].'">'.$data['sta_name'].'</option>';
                                    } 
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-3 control-label">Country</label>
                    <div class="col-xs-5" style="width:41.7%;">
                        <select class="form-control" name="country">
                            <option value="">Select a country</option>
                            <?php if(isset($userdata[0]['patient_country'])){
                                 $selected="selected";
                            }else{
                                $selected = "";
                            } ?>
                            <option value="US" <?php echo $selected;?>>United States</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-xs-3 control-label">Zip Code</label>
                    <div class="col-xs-5">
                        <input type="text" class="form-control" name="zipcode" onkeypress="return isNumberKey(event)" value="<?=(isset($userdata[0]['patient_zipcode']) && !empty($userdata[0]['patient_zipcode']) ? $userdata[0]['patient_zipcode'] :'' )?>" id="zipcode" maxlength="6"/>
                    </div>
                </div>
                <div class="form-group" style="margin-top: 15px;">
                    <div class="col-xs-5 col-xs-offset-3">
                       <button  class="btn btn-primary btn-next" id="btn-next" name="submit" type="submit" style="margin-left:10px;">Save and continue</button></a>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
</div>
<script>
 /*   jQuery("#btn-next").prop('disabled', true);
       var toValidate = jQuery('#datepicker, #telephone, #city ,#state,#country,#zipcode'),
            valid = false;
    toValidate.keyup(function () {
        if (jQuery(this).val().length > 0) {
            jQuery(this).data('valid', true);
        } else {
            jQuery(this).data('valid', false);
        }
        toValidate.each(function () {
            if (jQuery(this).data('valid') == true) {
                valid = true;
            } else {
                valid = false;
            }
        });
        if (valid === true) {
            jQuery("#btn-next").prop('disabled', false);
        } else {
            jQuery("#btn-next").prop('disabled', true);
        }
    }); */
</script>
<style>
    .home{
        background: #fff!important;
    }
    
</style>
<script>
      function isNumberKey(evt)
      {
         var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
      }
</script>
<?php require_once("includes/mfooter.php"); ?>