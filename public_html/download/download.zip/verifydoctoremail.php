<?php
date_default_timezone_set('Asia/Calcutta');
require_once("includes/top.php");
require_once("includes/header.php");
$email = base64_decode(trim($_GET['token']));
$db->Execute("update","update ".DOCTOR." SET doctor_status = '1' where UPPER(email) = '".  strtoupper($email)."'");
?>
<div class="container" style="height:350px;"><div class='alert alert-success fade in' style="margin-top:100px;">Your account has been activate , Please <a href="<?=$remotelocation."doctor_login.php"; ?>" >click here</a> for login..</div>
    
</div>
<?php require_once("includes/footer.php"); ?>

