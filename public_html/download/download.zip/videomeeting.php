<?php 
require_once("includes/top.php"); 
require_once("includes/header.php"); 
?>
<div class="container"><div class="row"><img src="<?=$remotelocation;?>includes/images/feeling-good.jpg" class="img-responsive margin-top-40"></div></div>
	   
      <div class="container">
    <div class="innercontent row">
    <div class="col-md-12" style="padding:10px 60px;">

<h4 class="text-center margin-bottom-40">You can get basic online consultation for a small fee at less <br>
than the cost of a meal. <br><a href="#." class="btn btn-default signup margin-top-30">Sign Up Now</a></h4>
<div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<p class="text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry.
 Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type 
 and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into 
 electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
 
 </p>
</div><div class="col-md-1"></div>
</div>
        <div class="video-wrapper">
        <div class="play-btn">  
            <a href="javascript:void(0)" class="play">
            <span class="play__inner-circle"></span>
            <span class="play__outer-circle"></span>
            <span class="play__icon"></span>
           </a></div>
        <img src="<?=$remotelocation;?>includes/images/03.jpg" class="img-responsive">
         </div><!--video wrapper-->
         
         <div class="youtube-play">
         	<div class="rmv"></div>
         	<div class="play-each">
         		<object width="100%" height="405px">
			  <param name="movie" value="http://www.youtube.com/v/aofd-J9jel8&autoplay=1&rel=0" />
			  <param name="wmode" value="transparent" />
			  <embed src="http://www.youtube.com/v/aofd-J9jel8&autoplay=1&rel=0"
			         type="application/x-shockwave-flash"
			         wmode="transparent" width="100%" height="405px" allowfullscreen="true" />
			</object>
         	</div>
         </div>
         
         <div class="row">
<div class="col-md-1"></div>
<div class="col-md-10">
<p class="text-center">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset</p>
</div><div class="col-md-1"></div>
</div>
        
        <div class="video-wrapper">
        <div class="play-btn">  
            <a href="javascript:void(0)" class="playa">
            <span class="play__inner-circle"></span>
            <span class="play__outer-circle"></span>
            <span class="play__icon"></span>
           </a></div>
        <img src="<?=$remotelocation;?>includes/images/04.jpg" class="img-responsive">
         </div>
    
    <div class="youtube-playa">
         	<div class="rmva"></div>
         	<div class="play-each">
         		<object width="100%" height="405px">
			  <param name="movie" value="http://www.youtube.com/v/T_DPE8i5LJU&autoplay=1&rel=0" />
			  <param name="wmode" value="transparent" />
			  <embed src="http://www.youtube.com/v/T_DPE8i5LJU&autoplay=1&rel=0"
			         type="application/x-shockwave-flash"
			         wmode="transparent" width="100%" height="405px" allowfullscreen="true" />
			</object>
         	</div>
         </div>
    
           
        
</div>
</div></div> 
<?php require_once("includes/footer.php"); ?>    