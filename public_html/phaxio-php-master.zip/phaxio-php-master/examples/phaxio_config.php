<?php

$apiKeys['live'] = 'fceceec1dcf22037e80e97e4814c567f07f323c5';
$apiSecrets['live'] = '67d73d2f33d5ecb84431cb359d3c106b979b01ca';
$apiKeys['test'] = '80e45281d8d43e3b7185a42056361dce46ac1812';
$apiSecrets['test'] = '4acce99dec2b6841763674707a286044a183e25f';
$apiMode = 'live';
$apiHost = 'https://api.phaxio.com/v1/';

$toNumber = '8884732963';
$customCallback = 'http://localphaxio.com/test';

$htmlData = <<<FAX
<html>
<head>
</head>
<body>
<div id="title" style="font-weight: bold">Hello. This is html.</div>
</body>
</html>
FAX;

$textData = <<<FAX
This is text data.
FAX;
