<?php

namespace Phaxio;

class PhaxioException extends \Exception
{
}
